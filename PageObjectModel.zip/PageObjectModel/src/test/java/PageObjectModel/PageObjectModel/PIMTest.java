package PageObjectModel.PageObjectModel;

import static org.testng.Assert.ARRAY_MISMATCH_TEMPLATE;
import static org.testng.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;
import jdk.internal.net.http.common.Log;

public class PIMTest {

	WebDriver driver;
	
	@BeforeTest
	public void beforetest() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	@Test
    public void AddNewEmployee() {  //RTM 2.2
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Login log = new Login(driver);
		
		PIM pim = new PIM(driver);
						
		log.LoginGoodCredentials();
	
			
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		
		}
		
		// pisi dodaj zaposlenog, uporedi employee list, ascending i descending , broj reportova, data import
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewEmployeeList");
		
		
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
			
			System.out.println(pim.RecordsNumber());
		
			pim.AddEmployeeClick();
			

			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			pim.EnterEmployeeData();
											
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
						
			SoftAssert softAssert = new SoftAssert(); 
			
			softAssert.assertTrue(pim.CompareResults().contains("First"));
			softAssert.assertTrue(pim.CompareResults().contains("Middle"));
			softAssert.assertTrue(pim.CompareResults().contains("Last"));
			softAssert.assertTrue(pim.CompareResults().contains("bcd"));
			
			softAssert.assertAll();
			
			
	}
	
	@Test
    public void ConfigurationDropdownOptionFields() {  //RTM 6.5
		//optional fields uradjene
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Login log = new Login(driver);
		
		PIM pim = new PIM(driver);
						
		log.LoginGoodCredentials();
	
			
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		
		}
		
		// pisi dodaj zaposlenog, uporedi employee list, ascending i descending , broj reportova, data import
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewEmployeeList");
			
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		pim.ConfigurationDropdown();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		pim.OptionalFieldClick();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(pim.OptionalFiledTitle());
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(pim.OptionFieldNumbers());
		
		
	//	WebElement IrctcLogo = driver.findElement(By.xpath("//span[@class='oxd-switch-input oxd-switch-input--active --label-right']"));
        	
		
		
		int OptNum = pim.OptionFieldAss();
		
	//	String elemsstring = driver.findElement(By.xpath("(//p[@class='oxd-text oxd-text--p orangehrm-optional-field-label'])[1]")).getText();

		SoftAssert softAssert = new SoftAssert(); 
						
		for (int i = 1; i <= OptNum; i++) {
			softAssert.assertEquals(true, pim.Irctlogo().isDisplayed());
			System.out.println(driver.findElement(By.xpath("(//p[@class='oxd-text oxd-text--p orangehrm-optional-field-label'])["+i+"]")).getText());
		}
		
		softAssert.assertAll();
	}
	
	@Test
    public void ConfigurationDropdownCustomFields() {  //RTM 6.6
		//optional fields uradjene
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Login log = new Login(driver);
		
		PIM pim = new PIM(driver);
						
		log.LoginGoodCredentials();
	
			
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		
		}
		
		// pisi dodaj zaposlenog, uporedi employee list, ascending i descending , broj reportova, data import
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewEmployeeList");
			
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		pim.ConfigurationDropdown();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		pim.CustomFieldClick();
		
		try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
				
		int z = pim.RecordsNumber() + pim.RemainingNumber();
				
		SoftAssert softAssert = new SoftAssert(); 
		
		softAssert.assertEquals(z,10);
				
		softAssert.assertAll();

	}
		
	@Test	
    public void ConfigurationDropdownReportingMethods() {  //RTM 6.7
		//optional fields uradjene
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		    
		Login log = new Login(driver);
		
		PIM pim = new PIM(driver);
						
		log.LoginGoodCredentials();
	
			
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		
		}
		
		// pisi dodaj zaposlenog, uporedi employee list, ascending i descending , broj reportova, data import
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewEmployeeList");
			
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		pim.ConfigurationDropdown();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		pim.ReportingMethodsClick();
				
		try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
						
		SoftAssert softAssert = new SoftAssert(); 
		
		softAssert.assertEquals(pim.ReportMethodsRowNumber(),pim.RecordsNumber());
				
		softAssert.assertAll();

	}
	
	@Test	
    public void ConfigurationDropdownTerminationReason() {  //RTM 6.8
		//optional fields uradjene
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		    
		Login log = new Login(driver);
		
		PIM pim = new PIM(driver);
						
		log.LoginGoodCredentials();
	
			
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		
		}
		
		// pisi dodaj zaposlenog, uporedi employee list, ascending i descending , broj reportova, data import
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewEmployeeList");
			
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		pim.ConfigurationDropdown();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		pim.TerminationReasonClick();
				
		try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
								
		SoftAssert softAssert = new SoftAssert(); 
		
		softAssert.assertEquals(pim.ReportMethodsRowNumber(),pim.RecordsNumber());
				
		softAssert.assertAll();

	}
	
	@Test	
    public void PIMHeadersElements() {  //RTM 6........
		//optional fields uradjene
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		    
		Login log = new Login(driver);
		
		PIM pim = new PIM(driver);
						
		log.LoginGoodCredentials();
	
			
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		
		}
		
		// pisi dodaj zaposlenog, uporedi employee list, ascending i descending , broj reportova, data import
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewEmployeeList");
			
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
						
		SoftAssert softAssert = new SoftAssert(); 
		
		for(int i = 1; i<=pim.PIMNumberOfHeadearDropdowns(); i++) {
			
			driver.findElement(By.xpath("(//span[@class='oxd-topbar-body-nav-tab-item'])["+i+"]")).click();
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
			
			System.out.println(pim.PIMNumberOfHeadearDropdowns());
			
			softAssert.assertTrue(pim.PIMNumberOfItemsInList() > 0);
			
			softAssert.assertTrue(pim.PIMNumberOfCharactersInItemInList() > 0);
		
			softAssert.assertAll();

	}
		
	}
	
}