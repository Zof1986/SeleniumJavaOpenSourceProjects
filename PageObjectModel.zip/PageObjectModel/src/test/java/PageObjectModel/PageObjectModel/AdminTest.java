package PageObjectModel.PageObjectModel;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AdminTest {

WebDriver driver;
	
	@BeforeTest
	public void beforetest() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	 @Test
	   public void AdminQualification() {  // RTM 5.5
			
			driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			driver.manage().window().maximize();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
						
			Login log = new Login(driver);
			
			Admin admin = new Admin(driver);
			
			log.LoginGoodCredentials();
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
	   
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/admin/viewSkills");
		
		//driver.findElement(By.xpath("//*[text()='Required']"));
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}			
		
		System.out.println(admin.RecordsNumber());
		
		System.out.println(admin.SkillCardNumber());
		
	//	Assert.assertEquals(admin.RecordsNumber(), admin.SkillCardNumber());
		
		
		//ovaj je admin.skillcardnumber
		String cardtext = driver.findElement(By.xpath("//div[@class='oxd-table-card']")).getText();
		admin.SkillCardNumber();
		System.out.println(admin.SkillCardNumber());
		//driver.findElement(By.xpath("(//button)[5]")).click();
		admin.EditButtonClick();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
	//	String value = driver.findElement(By.xpath("(//input)[2]")).getAttribute("value");
		
	//	String value1 = driver.findElement(By.xpath("//textarea")).getAttribute("value"); 
		
		System.out.println(admin.UpperCardValue() +" "+admin.LowerCardValue());
		
	//	driver.findElement(By.xpath("(//button)[3]")).click();
		
		admin.CardCancelButton();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		///
		
		System.out.println("krece lista");
		
		SoftAssert softAssert = new SoftAssert(); 
		
		List<WebElement> elementsxpath = driver.findElements(By.xpath("//div[@class='oxd-table-card']"));
		for(int i=1; i<=admin.SkillCardNumber(); i++) {
			String text = driver.findElement(By.xpath("(//div[@class='oxd-table-card'])["+i+"]")).getText();
		    System.out.println(text);
		    driver.findElement(By.xpath("(//button/i[@class='oxd-icon bi-pencil-fill'])["+i+"]")).click();
		 
		  //  admin.EditButtonClick();
		    
		    try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
		    
		    String valuenew = admin.UpperCardValue();
			
			String value1new = admin.LowerCardValue(); 
			
		//	System.out.println(valuenew +" "+value1new);
			
			softAssert.assertTrue(cardtext.contains(valuenew));
			softAssert.assertTrue(cardtext.contains(value1new));
			
		//	driver.findElement(By.xpath("(//button)[3]")).click();
			admin.CardCancelButton();
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
		}
		
		
		/*
		SoftAssert softAssert = new SoftAssert(); 
			
		softAssert.assertEquals(readynum, number);
		softAssert.assertTrue(cardtext.contains(value));  // ovo radi ali mora samo jedna rec a ne kako sam mislio
		softAssert.assertTrue(cardtext.contains(value1));
		
		softAssert.assertAll();*/
	   }
	 
	 @Test
	 public void AdminJobs() {
		 
		 driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			driver.manage().window().maximize();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
						
			Login log = new Login(driver);
			
			Admin admin = new Admin(driver);
			
			log.LoginGoodCredentials();
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
	   
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/admin/viewJobTitleList");
		
		//driver.findElement(By.xpath("//*[text()='Required']"));
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}	
		
		//napisi da li se poklapa broj rekorda sa brojem kartica, i uporedi da li se poklapa naslov i description sa otovorneom karticom
		
	//	admin.RecordsNumber();

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}	
		
		
		
		//admin.CardCancelButton();
		
		
		
SoftAssert softAssert = new SoftAssert(); 
//String cardtext = driver.findElement(By.xpath("//div[@class='oxd-table-card']")).getText();
		
String cardtext = driver.findElement(By.xpath("//div[@class='oxd-table-card']")).getText();

		List<WebElement> elementsxpath = driver.findElements(By.xpath("//div[@class='oxd-table-card']"));
	//	for(int i=1; i<=elementsxpath.size(); i++) {
			
		for(int i=1; i<=admin.SkillCardNumber(); i++) {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
			
			String text = driver.findElement(By.xpath("(//div[@class='oxd-table-card'])["+i+"]")).getText();
		    System.out.println(text);
		  //  driver.findElement(By.xpath("(//button/i[@class='oxd-icon bi-pencil-fill'])["+i+"]")).click();
		    driver.findElement(By.xpath("(//button/i[@class='oxd-icon bi-pencil-fill'])["+i+"]")).click();
		   
		    try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}	
		    
		    
		    admin.EditButtonClicknew();  //ovde je greska treba za svaki edit button da se otvori !!!!
		    
		    try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
		    
		  //  String valuenew = driver.findElement(By.xpath("(//input)[2]")).getAttribute("value");
		    String valuenew = admin.UpperCardValue();
			
		//	String value1new = driver.findElement(By.xpath("//textarea")).getAttribute("value"); 
			
			System.out.println(valuenew +" "/*+value1new*/);
			
			//softAssert.assertTrue(cardtext.contains(valuenew));
			softAssert.assertTrue(admin.SkillCardText().contains(valuenew));
		//	softAssert.assertTrue(cardtext.contains(value1new));
			
			
		//	driver.findElement(By.xpath("(//button)[3]")).click();
			admin.CardCancelButton();
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
		}
	 }
	 
	 @Test
	 public void AdminConfigurationEmailSubs() {   //ovaj dobar , ubaci novi RTM 5.10
		 
		 driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			driver.manage().window().maximize();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
						
			Login log = new Login(driver);
			
			Admin admin = new Admin(driver);
			
			log.LoginGoodCredentials();
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
	   
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/admin/viewEmailNotification");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
	//	System.out.println(admin.RecordsNumber());
		
	//	System.out.println(admin.SkillCardNumber());
		
		SoftAssert softAssert = new SoftAssert(); 
		
		softAssert.assertTrue((admin.RecordsNumber()) > 0);
		
		List<WebElement> elementsxpath = driver.findElements(By.xpath("//div[@class='oxd-table-card']"));
		//for(int i=1; i<=elementsxpath.size(); i++) {
		for(int i=1; i<=admin.ListSkillCard().size(); i++) {
		String CardText = driver.findElement(By.xpath("(//div[@class='oxd-table-card'])["+i+"]")).getText();
		int textnum = CardText.length();
	//	System.out.println(textnum);
		softAssert.assertTrue(textnum > 0);
		}
		
		softAssert.assertAll();
		// Lamguages i modules isto
	 }
	 
	 @Test
	 public void AdminLanguagesPackage() {   // , ubaci novi RTM 5.8
		 
		 driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			driver.manage().window().maximize();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
						
			Login log = new Login(driver);
			
			Admin admin = new Admin(driver);
			
			log.LoginGoodCredentials();
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
	   
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/admin/languagePackage");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		System.out.println(admin.RecordsNumber());
				
		System.out.println(admin.SkillCardNumber());
		
		SoftAssert softAssert = new SoftAssert(); 
		
		softAssert.assertTrue((admin.RecordsNumber()) > 0);
		
		List<WebElement> elementsxpath = driver.findElements(By.xpath("//div[@class='oxd-table-card']"));
	//	for(int i=1; i<=elementsxpath.size(); i++) {
		for(int i=1; i<=admin.ListSkillCard().size(); i++) {
		String CardText = driver.findElement(By.xpath("(//div[@class='oxd-table-card'])["+i+"]")).getText();
		int textnum = CardText.length();
		System.out.println(textnum);
		softAssert.assertTrue(textnum > 0);
		}
		
		softAssert.assertAll();
		//  modules isto
	 }
	 
	 @Test
	 public void AdminModules() {   // , ubaci novi RTM 5.11
		 
		 driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			driver.manage().window().maximize();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
						
			Login log = new Login(driver);
			
			Admin admin = new Admin(driver);
			
			log.LoginGoodCredentials();
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
	   
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/admin/viewModules");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		////div[@class='orangehrm-module-field-row']   sljader dugmici
		
		SoftAssert softAssert = new SoftAssert(); 
		
		softAssert.assertTrue(admin.ModuleTitle().matches("Module Configuration"));
		
		
		List<WebElement> elementsxpath = driver.findElements(By.xpath("//div[@class='orangehrm-module-field-row']"));
	//	for(int i=1; i<=elementsxpath.size(); i++) {
		for(int i=1; i<=admin.SwitchButtons().size(); i++) {
		String CardText = driver.findElement(By.xpath("(//div[@class='orangehrm-module-field-row'])["+i+"]")).getText();
		int textnum = CardText.length();
		//String Label = driver.findElement(By.xpath("(//label)["+i+"]")).getAttribute("class");
		//System.out.println(textnum+" "+Label);
		System.out.println(textnum);
		softAssert.assertTrue(textnum > 0);
		}
		
		
		softAssert.assertAll();
		
	 }
	 
	 
	//ul[@class='oxd-dropdown-menu']
	 
	 @Test
	 public void AdminHeaderElements() {   // , ubaci novi RTM 5......
		 
		 driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			driver.manage().window().maximize();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
						
			Login log = new Login(driver);
			
			Admin admin = new Admin(driver);
			
			log.LoginGoodCredentials();
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
	   
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/admin/viewSystemUsers");
		
		SoftAssert softAssert = new SoftAssert(); 
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
				
		//driver.findElement(By.xpath("(//span[@class='oxd-topbar-body-nav-tab-item'])[1]")).click();
		
		for(int i = 1; i<=admin.AdminNumberOfHeadearDropdowns(); i++) {
		
		driver.findElement(By.xpath("(//span[@class='oxd-topbar-body-nav-tab-item'])["+i+"]")).click();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		System.out.println(admin.AdminNumberOfItemsInList());
		
		softAssert.assertTrue(admin.AdminNumberOfItemsInList() > 0);
		
		softAssert.assertTrue(admin.AdminNumberOfCharactersInItemInList() > 0);
		
		}
		
		softAssert.assertAll();
		
	 }
	 

	 @Test
	 public void AdminNationalities() {   // , ubaci novi RTM 5. .....
		 // nesto posuntaci kada ulaizmo u kartice i vracamo se nazad
		 
		 driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			driver.manage().window().maximize();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
						
			Login log = new Login(driver);
			
			Admin admin = new Admin(driver);
			
			log.LoginGoodCredentials();
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
	   
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/admin/nationality");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		////div[@class='orangehrm-module-field-row']   sljader dugmici
		
		SoftAssert softAssert = new SoftAssert(); 
		
		softAssert.assertTrue(admin.ModuleTitle().matches("Nationalities"));
		
		
		//for(int j = 1; j)
		
		
		
		List<WebElement> elementsxpath = driver.findElements(By.xpath("//div[@class='oxd-table-card']"));
		
	//	for(int i=1; i<=elementsxpath.size(); i++) {
		for(int i=1; i<=admin.ListSkillCard().size(); i++) {
		String CardText = driver.findElement(By.xpath("(//div[@class='oxd-table-card'])["+i+"]")).getText();
		int textnum = CardText.length();
		
	//	driver.findElement(By.xpath("//i[@class='oxd-icon bi-pencil-fill']")).click();
		
		
		
	//	String vrednost = driver.findElement(By.xpath("(//div/input)[2]")).getAttribute("value");
		
	//	System.out.println("vrednostu u karticu "+vrednost);
		
	//	driver.findElement(By.xpath("(//button)[3]")).click();
		
				
		//String  = driver.findElement(By.xpath("(//label)["+i+"]")).getAttribute("class");
		//System.out.println(textnum+" "+Label);
		System.out.println(textnum+" "+CardText);
		softAssert.assertTrue(textnum > 0);
		
		
	
		
		
		
		softAssert.assertAll();
		System.out.println("Zavrsena strana ");
	//	driver.findElement(By.xpath("//button[@class='oxd-pagination-page-item oxd-pagination-page-item--previous-next']")).click();
		
		
		
		}
	 
	 }
	 
}
