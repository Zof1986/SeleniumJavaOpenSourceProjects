package PageObjectModel.PageObjectModel;

import static org.testng.Assert.ARRAY_MISMATCH_TEMPLATE;
import static org.testng.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;
import jdk.internal.net.http.common.Log;

public class PerformanceTest {

	WebDriver driver;
	
	@BeforeTest
	public void beforetest() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	@Test
	public void PerformanceCreateNewLog() {  //RTM 9........
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Performance perform = new Performance(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/performance/viewMyPerformanceTrackerList");
				
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		
		SoftAssert softAssert = new SoftAssert();
		 
		 softAssert.assertEquals(perform.RemainingNumber(), perform.OptionFieldAss());
		
		//String FirstRow = driver.findElement(By.xpath("//div[@class='oxd-table-card']")).getText();
		
		//System.out.println(FirstRow);
		
		//driver.findElement(By.xpath("//button[text()=' View ']")).click();
		
		perform.ViewButton();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
	
		
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		//driver.findElement(By.xpath("//button[text()=' Add Log ']")).click();
		
		perform.AddLog();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		
		//Popunjavanje forme
		/*
		driver.findElement(By.xpath("(//input)[2]")).sendKeys("Log test");
		
		driver.findElement(By.xpath("//textarea")).sendKeys("Comment test");
		
		driver.findElement(By.xpath("//button[@class='oxd-button oxd-button--medium oxd-button--text orangehrm-tracker-rating-button']")).click();
		
		driver.findElement(By.xpath("//button[text()=' Save ']")).click();
		*/
		
		perform.FormFilling();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		
		
		WebElement firstrow = driver.findElement(By.xpath("//div[@class='oxd-sheet oxd-sheet--rounded oxd-sheet--gray-lighten-2 orangehrm-scroll-card']"));
		
		
	//	String novavrednost = firstrow.getText();
			
		//System.out.println(perform.RemainingNumber() +" "+ perform.OptionFieldAss());
		//System.out.println("Pre asserta "+novavrednost );
		
		
		 
		 softAssert.assertTrue(perform.FirstRow().contains("Log test"));
		 
		 softAssert.assertTrue(perform.FirstRow().contains("Comment test"));
					 
		 softAssert.assertNotNull(perform.FirstRowElement(),"Element not present");
		 
		 try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
		 
	//	 driver.findElement(By.xpath("(//button[@class='oxd-icon-button'])[2]")).click();
		perform.ThreeDotsEditDelete();
		 
		 try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
		 
		// driver.findElement(By.xpath("//p[text()='Delete']")).click();
		 perform.ThreeDotsDelete();
		 
		 try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
		 
		 
		// driver.findElement(By.xpath("//button[text()=' Yes, Delete ']")).click();
		 perform.DeleteConfirm();
		 try {
				Thread.sleep(4000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
		 
			//WebElement SecondRow =	driver.findElement(By.xpath("//div[@class='oxd-sheet oxd-sheet--rounded oxd-sheet--gray-lighten-2 orangehrm-scroll-card']"));
			
		 
		 softAssert.assertNull(perform.FirstRowElement(),"Element not present");
		 
		 softAssert.assertAll();
		 }
	
	@Test	
    public void PerformanceHeadersElements() {  //RTM 6........
		//optional fields uradjene
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		    
		Login log = new Login(driver);
		
		Performance perform = new Performance(driver);
						
		log.LoginGoodCredentials();
	
			
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		
		}
		
		// pisi dodaj zaposlenog, uporedi employee list, ascending i descending , broj reportova, data import
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/performance/searchEvaluatePerformanceReview");
			
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
						
		SoftAssert softAssert = new SoftAssert(); 
		
		System.out.println(perform.PerformanceNumberOfHeadearDropdowns());
		
		for(int i = 1; i<=perform.PerformanceNumberOfHeadearDropdowns(); i++) {
			
			driver.findElement(By.xpath("(//span[@class='oxd-topbar-body-nav-tab-item'])["+i+"]")).click();
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
			
			System.out.println(perform.PerformanceNumberOfItemsInList());
			
			softAssert.assertTrue(perform.PerformanceNumberOfItemsInList() > 0);
			
			softAssert.assertTrue(perform.PerformanceNumberOfCharactersInItemInList() > 0);
		
			softAssert.assertAll();

	}
		
	}


}