package PageObjectModel.PageObjectModel;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Directory {

	
WebDriver driver;
	
	public Directory(WebDriver driver) {
		this.driver = driver;
	}
	
	By ItemInList = By.xpath("//ul[@class='oxd-dropdown-menu']/li/a");
	
	By HeaderDropdowns = By.xpath("//span[@class='oxd-topbar-body-nav-tab-item']");
	
	By EmployerName = By.xpath("//input[@placeholder='Type for hints...']");
	
	By Reset = By.xpath("(//button)[4]");
	
	By DropdownElement = By.xpath("//div[@class='oxd-form-row']/div/div");
	
	By ScrollableContainer = By.xpath("//div[@class='orangehrm-container']");
	
	By CardElements = By.xpath("//div[@class='oxd-grid-item oxd-grid-item--gutters']");
	
	By CardListPath = By.xpath("//div[@class='orangehrm-container']/div/div");
	
	public int ClaimNumberOfItemsInList() {
		List<WebElement> lst = driver.findElements(ItemInList);
		int TotalItemsInList = lst.size();
		return TotalItemsInList;
	}
	
	public int ClaimNumberOfCharactersInItemInList() {
		String Text = driver.findElement(ItemInList).getText();
		int NumberOfText = Text.length();
		return NumberOfText;
	}
	
	public int ClaimNumberOfHeadearDropdowns() {
		List<WebElement> lst = driver.findElements(HeaderDropdowns);
		int TotalDropdownsInHeader = lst.size();
		return TotalDropdownsInHeader;
	}
			
	public void EmployeeNameSendText() {
		WebElement NamePlaceholder = driver.findElement(EmployerName);
		NamePlaceholder.sendKeys("test");
	}
	
	public String EmployeeNameValue() {
		String  NamePlaceholder = driver.findElement(EmployerName).getAttribute("value");
		return NamePlaceholder;
	}
	
	public String EmployeeNameValueAfterReset() {
		String  NamePlaceholder = driver.findElement(EmployerName).getAttribute("value");
		return NamePlaceholder;
	}
		
	public void ResetButton() {
		driver.findElement(Reset).click();
	}
	
	public int DropdownElements() {		
		List<WebElement> lst = driver.findElements(DropdownElement);
		int TotalDropdownsInHeader = lst.size();
		return TotalDropdownsInHeader;
	}
	
	public void DynamicScroll() {
		try {
            
            // Locate the inner scrollable container
            WebElement scrollableContainer = driver.findElement(ScrollableContainer); // Adjust the selector
            
            // Cast driver to JavaScriptExecutor
            JavascriptExecutor js = (JavascriptExecutor) driver;
            
            // Initialize variables to keep track of elements
            List<WebElement> elementsBeforeScroll;
            List<WebElement> elementsAfterScroll;
            
            // Loop to scroll down inside the inner container until no new content is loaded
            while (true) {
                // Get the elements before scrolling
                elementsBeforeScroll = scrollableContainer.findElements(CardElements); // Adjust the selector
                
                // Scroll down within the inner container
                js.executeScript("arguments[0].scrollTop = arguments[0].scrollHeight;", scrollableContainer);
                
                // Wait to load the new content
                Thread.sleep(2000); // Adjust the sleep duration according to the loading time
                
                // Get the elements after scrolling
                elementsAfterScroll = scrollableContainer.findElements(CardElements); // Adjust the selector
                
                // Check if new elements are loaded
                if (elementsAfterScroll.size() == elementsBeforeScroll.size()) {
                    break; // Exit the loop if no new content is loaded
                }
            }
            
            // Optional: Find elements after fully loading the content
            for (WebElement element1 : elementsAfterScroll) {
                System.out.println(element1.getText());
                element1.click();
                	                
            }
         //   WebElement Cards = driver.findElement(By.xpath("//div[@class='orangehrm-container']/div/div"));
            List<WebElement> CardList = driver.findElements(CardListPath);
            int NumberCards = CardList.size();
            System.out.println("Number of Cards "+NumberCards);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
	}
}
