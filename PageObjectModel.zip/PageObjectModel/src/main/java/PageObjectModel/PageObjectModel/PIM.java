package PageObjectModel.PageObjectModel;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PIM {

WebDriver driver;
	
	public PIM(WebDriver driver) {
		this.driver = driver;
	}
	
	By RecordsPath = By.xpath("(//span)[16]");
	
	By RemainingPath = By.xpath("//p[@class='oxd-text oxd-text--p --infotext']");
	
	By AddEmployeeButton = By.xpath("//button[@class='oxd-button oxd-button--medium oxd-button--secondary']");
	
	By FirstName = By.xpath("(//input)[3]");
	
	By MiddleName = By.xpath("(//input)[4]");
	
	By LastName = By.xpath("(//input)[5]");
	
	By EmployeeId = By.xpath("(//input)[6]");
	
	By SaveButton = By.xpath("//button[@type='submit']");
	
	By CardToCompare = By.xpath("(//div[@class='oxd-table-card'])[1]");
	
	By Dropdown = By.xpath("//span[contains(text(),'Configuration')]");
	
	By OptionalFields = By.xpath("//*[contains(text(), 'Optional Fields')]");
	
	By CustomFields = By.xpath("//*[contains(text(), 'Custom Fields')]");
	
	By ReportingMethods = By.xpath("//*[contains(text(), 'Reporting Methods')]");
	
	By TerminationReason = By.xpath("//*[contains(text(), 'Termination Reasons')]");
	
	By OptionalFieldTitle = By.xpath("//p[@class='oxd-text oxd-text--p orangehrm-main-title']");
	
	By OptionFileds = By.xpath("//div[@class='orangehrm-optional-field-row']");
	
	By RemaingRecordNumbers = By.xpath("//p[@class='oxd-text oxd-text--p --infotext']");
	
	By IrtcLogo = By.xpath("//span[@class='oxd-switch-input oxd-switch-input--active --label-right']");
	
	By ReportMethodsRows = By.xpath("//div[@class='oxd-table-card']");
	
    By ItemInList = By.xpath("//ul[@class='oxd-dropdown-menu']/li/a");
	
	By HeaderDropdowns = By.xpath("//span[@class='oxd-topbar-body-nav-tab-item']");
	
	public int RecordsNumber() {
		String records = driver.findElement(RecordsPath).getText();		
		//	System.out.println(records);		
			String ready = records.substring(records.indexOf('(') + 1, records.indexOf(')'));	
			int readynum = Integer.parseInt(ready);
			return readynum;
	}
	
	public int RemainingNumber() {
		String testni = driver.findElement(RemainingPath).getText();
		String last = testni.substring(testni.lastIndexOf(' ') + 1);
		int readynum = Integer.parseInt(last);
		return readynum;
	}
	
	
	
	
	
	public void AddEmployeeClick() {
		driver.findElement(AddEmployeeButton).click();
	}
	
	public void EnterEmployeeData() {
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		driver.findElement(FirstName).sendKeys("First");
		driver.findElement(MiddleName).sendKeys("Middle");
		driver.findElement(LastName).sendKeys("Last");
		driver.findElement(EmployeeId).sendKeys("bcd");
		driver.findElement(SaveButton).click();
	}
	
	public String CompareResults() {
		String TextCard = driver.findElement(CardToCompare).getText();
		return TextCard;
	}
	
	public void ConfigurationDropdown() {
		driver.findElement(Dropdown).click();
	}
	
	public void OptionalFieldClick() {
		driver.findElement(OptionalFields).click();
	}
	
	public void CustomFieldClick() {
		driver.findElement(CustomFields).click();
	}
	
	public void ReportingMethodsClick() {
		driver.findElement(ReportingMethods).click();
	}
			
	public void TerminationReasonClick() {
		driver.findElement(TerminationReason).click();
	}
		
	public String OptionalFiledTitle() {
		return driver.findElement(OptionalFieldTitle).getText();
	}
	
	public int OptionFieldNumbers() {
		List<WebElement> lst = driver.findElements(OptionFileds);
		int OptNum = lst.size();
		return OptNum;
		
	}
	
	public int OptionFieldAss() {
		List<WebElement> lst = driver.findElements(OptionFileds);
		int OptNum = lst.size();
		return OptNum;
	}
	
	public int ReportMethodsRowNumber() {
		List<WebElement> lst = driver.findElements(ReportMethodsRows);
		int OptNum = lst.size();
		return OptNum;
	}
	
	public WebElement Irctlogo() {
		WebElement IrctcLogo = driver.findElement(IrtcLogo);
	    return IrctcLogo;		
	}
	
	public int PIMNumberOfItemsInList() {
		List<WebElement> lst = driver.findElements(ItemInList);
		int TotalItemsInList = lst.size();
		return TotalItemsInList;
	}
	
	public int PIMNumberOfCharactersInItemInList() {
		String Text = driver.findElement(ItemInList).getText();
		int NumberOfText = Text.length();
		return NumberOfText;
	}
	
	public int PIMNumberOfHeadearDropdowns() {
		List<WebElement> lst = driver.findElements(HeaderDropdowns);
		int TotalDropdownsInHeader = lst.size();
		return TotalDropdownsInHeader;
	}
		
}
