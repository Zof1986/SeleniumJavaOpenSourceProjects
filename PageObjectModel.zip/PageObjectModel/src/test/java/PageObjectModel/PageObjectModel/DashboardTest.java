package PageObjectModel.PageObjectModel;

import static org.testng.Assert.ARRAY_MISMATCH_TEMPLATE;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;
import jdk.internal.net.http.common.Log;

public class DashboardTest {

	WebDriver driver;
	
	@BeforeTest
	public void beforetest() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	@Test
	public void DashboardTimeAtWork() {  //RTM 9........
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Dashboard dash = new Dashboard(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index");
				
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
	//System.out.println(time +" uporedi "+bigtime);
		
		SoftAssert softAssert = new SoftAssert();
		
		softAssert.assertTrue(dash.BigTimeResult().contains(dash.SmallTimeResult()));		
	
		softAssert.assertAll();
	}
	
	@Test
	public void DashboardMyAction() {  //RTM 9........
		//treba doraditi
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Dashboard dash = new Dashboard(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index");
				
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		System.out.println(dash.MyActionsToDoNumber());
			
		SoftAssert softAssert = new SoftAssert();
			
		softAssert.assertNotNull(dash.MyActionsToDoNumber(), "Not Present");
		
		softAssert.assertNotNull(dash.PresentElement(), "Not Present");
		
		String FirstRowtext	= driver.findElement(By.xpath("(//div[@class='orangehrm-todo-list-item']/p)[1]")).getText();
	    
		//
	//	System.out.println(FirstRowtext);
		
	//	dash.RemainingNumber();
	//	System.out.println(dash.RemainingNumber());
		
	//	dash.RemainingText()
	//	System.out.println(dash.RemainingText());
		//
		
		for(int i = 1; i<dash.MyActionsToDoNumber(); i++) {
			
			
			driver.findElement(By.xpath("(//div[@class='orangehrm-todo-list-item'])[1]")).click();
			
		}
		
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	    String Afteropens =	driver.findElement(By.xpath("(//span[@class='oxd-text oxd-text--span'])[1]")).getText();
	
		dash.RemainingNumberAfterActionOpens();
		
		System.out.println("broj kad se otvori " +dash.RemainingNumberAfterActionOpens());
		
		//tu ubacis prvu asertaciju broj pre otvaranj i posle otvaranja
		
		driver.findElement(By.xpath("//div[@class='oxd-table-card']"));
		
		List<WebElement> lstnew = driver.findElements(By.xpath("//div[@class='oxd-table-card']"));
		int ViewNumnew = lstnew.size();
		
		// ovde drugu gde uporedis broj na vrhu sa pobrojanim elmeentima
		
		
		
	//	softAssert.assertTrue(dash.BigTimeResult().contains(dash.SmallTimeResult()));		
	
		softAssert.assertAll();
	}

	@Test
	public void DashboardBuzzLatestPosts() {  //RTM 9........
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Dashboard dash = new Dashboard(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index");
				
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
	//System.out.println(time +" uporedi "+bigtime);
		SoftAssert softAssert = new SoftAssert();
		
		
		WebElement Card = driver.findElement(By.xpath("//div[@class='oxd-grid-item oxd-grid-item--gutters orangehrm-buzz-widget-card']"));
		
		WebElement Date = driver.findElement(By.xpath("//p[@class='oxd-text oxd-text--p orangehrm-buzz-widget-header-time']"));
		
		System.out.println(dash.PostCardNumbers());
		
		String CardData = driver.findElement(By.xpath("(//div[@class='oxd-grid-item oxd-grid-item--gutters orangehrm-buzz-widget-card'])[3]")).getText();
		//System.out.println(CardData);
		
		
		for(int i=1;i<=dash.PostCardNumbers();i++) {
		String kartice = driver.findElement(By.xpath("(//p[@class='oxd-text oxd-text--p orangehrm-buzz-widget-body'])["+i+"]")).getText();
	//	System.out.println(kartice.length());	
		softAssert.assertTrue(kartice.length() > 0);
		}
		
		
		softAssert.assertNotNull(Card,"Not Present");
		
		softAssert.assertTrue(dash.PostCardNumbers() > 0);
		
		
		
		//softAssert.assertTrue(dash.BigTimeResult().contains(dash.SmallTimeResult()));		
	
		softAssert.assertAll();
	}
	
	@Test
	public void QuickLaunch() {  //RTM 9........
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Dashboard dash = new Dashboard(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index");
				
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		SoftAssert softAssert = new SoftAssert();
		
		System.out.println(dash.QuickLaunchNumberCards());
	
		
		for(int i = 1; i<=dash.QuickLaunchNumberCards(); i++) {
			String IconText = driver.findElement(By.xpath("(//div[@class='oxd-grid-item oxd-grid-item--gutters orangehrm-quick-launch-card'])["+i+"]")).getText();
			System.out.println(IconText);
			
			softAssert.assertTrue(IconText.length() > 0);
		}
		
		Actions action = new Actions(driver);
		
		for(int i = 1; i<=dash.QuickLaunchNumberCards(); i++) {
			
			String HooverColor1 =driver.findElement(By.xpath("(//div[@class='oxd-grid-item oxd-grid-item--gutters orangehrm-quick-launch-card'])["+i+"]")).getCssValue("color");
			System.out.println(HooverColor1);
			
		action.moveToElement(driver.findElement(By.xpath("(//div[@class='oxd-grid-item oxd-grid-item--gutters orangehrm-quick-launch-card'])["+i+"]"))).build().perform();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		String HooverColor =driver.findElement(By.xpath("(//button[@class='oxd-icon-button orangehrm-quick-launch-icon'])["+i+"]")).getCssValue("color");
		System.out.println(HooverColor);
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		}
		
		//
				
		for(int i = 1; i<=dash.QuickLaunchNumberCards(); i++) {
			String OldUrl = driver.getCurrentUrl();			
			String IconText = driver.findElement(By.xpath("(//p[@class='oxd-text oxd-text--p --text'])["+i+"]")).getText();
			String ChangedIconText = IconText.replace(" ", "");
			
			driver.findElement(By.xpath("(//div[@class='oxd-grid-item oxd-grid-item--gutters orangehrm-quick-launch-card'])["+i+"]")).click();
				System.out.println(OldUrl);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		String NewUrl = driver.getCurrentUrl();
		System.out.println(NewUrl);
		
		softAssert.assertTrue(NewUrl.toLowerCase().contains(ChangedIconText.toLowerCase()), "URL does not contain the expected text!");
		
		driver.navigate().back();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		
		}
		//
		
		softAssert.assertAll();
	}
	
	//napravi kada se klikne na one 6 u quick lanch ikone da li se otvaraju URL sa onim imenima 
	
	@Test
	public void EmployeeDistribution() {  //RTM 9........
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Dashboard dash = new Dashboard(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index");
				
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		SoftAssert softAssert = new SoftAssert();
				
		System.out.println(dash.EmployeeDistribution());
		
		for(int i = 1; i<=dash.EmployeeDistribution(); i++) {
			
			driver.findElement(By.xpath("(//ul[@class='oxd-chart-legend']/li)["+i+"]")).click();
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
			String Style = driver.findElement(By.xpath("(//ul[@class='oxd-chart-legend']/li//span[2])["+i+"]")).getAttribute("style");
			System.out.println(Style);
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
		}
		
		softAssert.assertAll();
	}

}