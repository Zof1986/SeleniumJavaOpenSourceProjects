package PageObjectModel.PageObjectModel;

import static org.testng.Assert.ARRAY_MISMATCH_TEMPLATE;
import static org.testng.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;
import jdk.internal.net.http.common.Log;

public class LoginTest {

	WebDriver driver;
	
	@BeforeTest
	public void beforetest() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	@Test
	public void LoginValidData() {    //RTM 1.1 1.5 nevalidni kredencijali
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
				
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	Login log = new Login(driver);
  	
	String tit = log.gettitle();
  	
	System.out.println("Ovo je string od drugoga objekta " + tit);
		
	log.ForgetPasswordButton();
	
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	System.out.println("URL od druge "+log.ForgotPasswordURL());
	
	log.ForgotPasswordinsert();
	log.CancelButtonClick();	
	
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	System.out.println("poslato uspesno "+log.ResetLink());
	driver.navigate().back();

	log.LoginButtonClick();
	
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
			
	log.Login();
	
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	System.out.println("Error je "+log.ErrorLogin());
			
	log.LoginGoodCredentials();
	
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	System.out.println("Profile name "+log.ProfileName());
	
	Assert.assertEquals(log.ProfileName(), "sejal sawalkar");
	
	}
	
	@Test
	public void LoginInvalidData() {    // RTM 1.2 1.3 1.4
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
						
		Login log = new Login(driver);
		
		log.LoginSpace();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
	
		//
	
	driver.navigate().refresh();
	
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	log.LoginAdminSpace();
	
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();   
	}
	
	
	//
	driver.navigate().refresh();
	
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	log.LoginPasswordSpace();
	
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();   
	}
				
	SoftAssert softAssert = new SoftAssert();
	
	softAssert.assertEquals(log.FirstErrorLog(), "Required");
	softAssert.assertEquals(log.FirstErrorLog(), "Required");
	softAssert.assertEquals(log.FirstErrorLog(), "Required");
	softAssert.assertEquals(log.FirstErrorLog(), "Required");
	
	softAssert.assertAll();
	}
}