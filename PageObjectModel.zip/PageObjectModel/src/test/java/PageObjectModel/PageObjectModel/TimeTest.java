package PageObjectModel.PageObjectModel;

import static org.testng.Assert.ARRAY_MISMATCH_TEMPLATE;
import static org.testng.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;
import jdk.internal.net.http.common.Log;

public class TimeTest {

	WebDriver driver;
	
	@BeforeTest
	public void beforetest() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	@Test
	public void ViewVithOutParameters() {  //RTM 8.2
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Time time = new Time(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/time/viewEmployeeTimesheet");
				
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
				
		time.SubmitClick();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		System.out.println(time.Errortext());
				
		SoftAssert softAssert = new SoftAssert();
		
		softAssert.assertEquals(time.Errortext(), "Required");
		
		softAssert.assertAll();
		
	}
	
	
	@Test
	public void NumberOfRecords() {  //RTM 8.3
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Time time = new Time(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/time/viewEmployeeTimesheet");
				
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
			
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		System.out.println(time.RemainingNumber());
				
		SoftAssert softAssert = new SoftAssert();
		
		softAssert.assertEquals(time.RemainingNumber(), time.OptionFieldAss());
		
		softAssert.assertAll();
		
	}
	
	@Test
	public void NameRecordsAfterView() {  //RTM 8.2
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Time time = new Time(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/time/viewEmployeeTimesheet");
				
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
				
		
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		System.out.println(time.ViewButtonNumber());
		
		SoftAssert softAssert = new SoftAssert();
	
				
		for (int i = 1; i <= time.ViewButtonNumber(); i++) {
			//dodaj ovde string i uporedi posle u assert contains drugi text
			System.out.println(driver.findElement(By.xpath("(//div[@class='oxd-table-card'])["+i+"]")).getText());
			
			String textone = driver.findElement(By.xpath("(//div[@class='oxd-table-card'])["+i+"]")).getText();
						
			driver.findElement(By.xpath("(//button[@class='oxd-button oxd-button--medium oxd-button--text oxd-table-cell-action-space'])["+i+"]")).click();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
			System.out.println("stampam kada ga otvorim");
		//	System.out.println(driver.findElement(By.xpath("//div[@class='oxd-table-card']")).getText());
			System.out.println(time.EmployeeRow());
						
			String texttwo = time.EmployeeRow();
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
			
			//softAssert.assertTrue(textone.contains(texttwo));
			//ovo moram da proucim ne radi mi kako ocekujem
			
			driver.navigate().back();
		}
						
		softAssert.assertAll();
		
	}
	
	@Test
	public void AttendencyRecords() {  //RTM 8.5
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Time time = new Time(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/attendance/viewAttendanceRecord");
				
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
					
		SoftAssert softAssert = new SoftAssert();
		
		for (int i = 1; i <= time.ViewButtonNumber(); i++) {
			
			String textone = driver.findElement(By.xpath("(//div[@class='oxd-table-card'])["+i+"]/div/div[2]")).getText();
					
			driver.findElement(By.xpath("(//button[@class='oxd-button oxd-button--medium oxd-button--text oxd-table-cell-action-space'])["+i+"]")).click();
		
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
					
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
												
			softAssert.assertEquals(textone,time.LastNumber());
						
			driver.navigate().back();
		}
						
		softAssert.assertAll();
	}
	
	@Test
	public void AttendencyConfiguration() {  //RTM 8.6
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Time time = new Time(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/attendance/configure");
				
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
					
		SoftAssert softAssert = new SoftAssert();
	 
	 for(int i = 1; i<=time.AttendencieWebElementSize(); i++) {
		WebElement FirstElmenet =	driver.findElement(By.xpath("(//div[@class='orangehrm-attendance-field-row'])["+i+"]"));
		WebElement SecondElement =	driver.findElement(By.xpath("(//div[@class='oxd-switch-wrapper'])["+i+"]"));
		softAssert.assertTrue(FirstElmenet.isDisplayed() && SecondElement.isDisplayed());
	 }
				
		softAssert.assertAll();
		
	}
	
	@Test
	public void CustomersDescAsc() {  //RTM 8.7
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Time time = new Time(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/time/viewCustomers");
				
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
					//uradi ascending descending i da li imaju prazan text u body 
		SoftAssert softAssert = new SoftAssert();
		
		/*String First = driver.findElement(By.xpath("(//div[@class='oxd-table-card'])[4]/div/div[2]")).getText();
		System.out.println(First);
		String Second = driver.findElement(By.xpath("(//div[@class='oxd-table-card'])[4]/div/div[3]")).getText();
		System.out.println(Second);*/
		
        //System.out.println(time.RowSorting());
		
		
		String Asc = time.RowSorting();
		
		time.SortButtonClick();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
				
		time.DescendingOrder();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		 
	    //System.out.println(time.RowSorting());
		
		String Desc = time.RowSorting();
	
		softAssert.assertNotEquals(Asc, Desc);
			  	
		softAssert.assertAll();
		
	}
	
	@Test
	public void CustomersNameDescription() {  //RTM 8.8
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Time time = new Time(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/time/viewCustomers");
				
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
					
		SoftAssert softAssert = new SoftAssert();
						
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
				
		for(int i = 1; i <=time.OptionFieldAss(); i ++) {
			String First = driver.findElement(By.xpath("(//div[@class='oxd-table-card'])["+i+"]/div/div[2]")).getText();
			int FirstOne = First.length();
		//	System.out.println(FirstOne);
						
			String Second = driver.findElement(By.xpath("(//div[@class='oxd-table-card'])["+i+"]/div/div[3]")).getText();
			int SecondTwo = Second.length();
		//	System.out.println(SecondTwo);
			
			softAssert.assertTrue(FirstOne > 0);
			softAssert.assertTrue(SecondTwo > 0);
		}
				
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
			  					  	
		softAssert.assertAll();
		
	}
	
	@Test
	public void ProjectsNameDescription() {  //RTM 8.9
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Time time = new Time(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/time/viewProjects");
				
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
					
		SoftAssert softAssert = new SoftAssert();
						
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
				
		for(int i = 1; i <=time.OptionFieldAss(); i ++) {
			String First = driver.findElement(By.xpath("(//div[@class='oxd-table-card'])["+i+"]/div/div[2]")).getText();
			int FirstOne = First.length();
			System.out.println(FirstOne);
						
			String Second = driver.findElement(By.xpath("(//div[@class='oxd-table-card'])["+i+"]/div/div[3]")).getText();
			int SecondTwo = Second.length();
			System.out.println(SecondTwo);
			
			String Third = driver.findElement(By.xpath("(//div[@class='oxd-table-card'])["+i+"]/div/div[4]")).getText();
			int ThirdThree = Third.length();
			System.out.println(ThirdThree);
			
			softAssert.assertTrue(FirstOne > 0);
			softAssert.assertTrue(SecondTwo > 0);
			softAssert.assertTrue(ThirdThree > 0);
		}
				
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
			  					  	
		softAssert.assertAll();		
	}
	
	@Test
	public void TimeHeadersElements() {  //RTM 8......
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Time time = new Time(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/time/viewEmployeeTimesheet");
				
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
					
		SoftAssert softAssert = new SoftAssert();
		
			 
		for(int i = 1; i<=time.TimeNumberOfHeadearDropdowns(); i++) {
			
			driver.findElement(By.xpath("(//span[@class='oxd-topbar-body-nav-tab-item'])["+i+"]")).click();
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
			
			
			
			softAssert.assertTrue(time.TimeNumberOfItemsInList() > 0);
			
			softAssert.assertTrue(time.TimeNumberOfCharactersInItemInList() > 0);
				
		}
		softAssert.assertAll();
	}
	
}