package PageObjectModel.PageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import io.github.bonigarcia.wdm.WebDriverManager;

public class Login {

	
	WebDriver driver;
	
	public Login(WebDriver driver) {
		this.driver = driver;
	}
	
	By TitleXpath = By.xpath("//h5");
	
	By ForgetbuttonXpath = By.xpath("(//p)[3]");
	
	By ForgetTextField = By.xpath("(//input)[2]");
	
	By CancelButton = By.xpath("(//button)[2]");
	
	By Resetlink = By.xpath("//h6");
	
	By LoginButton = By.xpath("(//button)[1]");
	
	By UserName = By.xpath("(//input)[2]");
	
	By Password = By.xpath("(//input)[3]");
	
	By LoginError = By.xpath("(//p)[1]");
	
	By ProfileName = By.xpath("//p");
	
	By FirstError = By.xpath("(//span)[1]");
	
	By SecondError = By.xpath("(//span)[2]");
	
	public String gettitle() {
		return driver.findElement(TitleXpath).getText();
	}
	
	public void ForgetPasswordButton() {
		driver.findElement(ForgetbuttonXpath).click();
	}
	
	public String ForgotPasswordURL() {
		return driver.getCurrentUrl();
	}
	
	public void ForgotPasswordinsert() {
		driver.findElement(ForgetTextField).sendKeys("test");
	}
	
	public void CancelButtonClick() {
		driver.findElement(CancelButton).click();
	}
	
	public String ResetLink() {
		return driver.findElement(Resetlink).getText();
	}
	
	public void LoginButtonClick() {
		driver.findElement(LoginButton).click();
	}
	
	public void Login() {
		driver.findElement(UserName).sendKeys("aor");
		driver.findElement(Password).sendKeys("123");
		driver.findElement(LoginButton).click();
	}
	
	public String ErrorLogin() {
		return driver.findElement(LoginError).getText();
	}
	
	public void LoginGoodCredentials() {
		driver.findElement(UserName).sendKeys("Admin");
		driver.findElement(Password).sendKeys("admin123");
		driver.findElement(LoginButton).click();
	}
	
	public String ProfileName() {
	  return driver.findElement(By.xpath("//p")).getText();
	}
	
	public void LoginSpace() {
		driver.findElement(UserName).sendKeys(" ");
		driver.findElement(Password).sendKeys(" ");
		driver.findElement(LoginButton).click();
	}
	
	public String FirstErrorLog() {
		return driver.findElement(FirstError).getText();
	}
	
	public String SecondErrorLog() {
		return driver.findElement(SecondError).getText();
	}
	
	public void LoginAdminSpace() {
		driver.findElement(UserName).sendKeys("Admin");		
		driver.findElement(Password).sendKeys(" ");		
		driver.findElement(LoginButton).click();
	}
	
	public void LoginPasswordSpace() {
		driver.findElement(UserName).sendKeys(" ");		
		driver.findElement(Password).sendKeys("admin123 ");		
		driver.findElement(LoginButton).click();
	}
}
