package TestScenarios;

import static org.testng.Assert.assertNotEquals;

import java.util.List;
import java.util.Set;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Object.GoogleSearch;
import PageObjectModel.PageObjectModel.TestAutomation;
import io.github.bonigarcia.wdm.WebDriverManager;

public class TestMethodGoogleSearch {

	WebDriver driver;
	
	@BeforeTest
	public void beforetest() {
		WebDriverManager.chromedriver().driverVersion("125.0.6422.60").setup();
		driver = new ChromeDriver();
		
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		 
	}
		
	//https://testautomationpractice.blogspot.com/

	@Test
	public void FindNewUrl() {
		TestAutomation auto = new TestAutomation(driver);
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//System.out.println(driver.getCurrentUrl());
		System.out.println(auto.CurrentUrl());
		
		String OldUrl = auto.CurrentUrl();	
		
		auto.ClickNewBrowserButton();
			
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
						
		auto.SwitchToNewWindow();
		
		//System.out.println(driver.getCurrentUrl());
		System.out.println(auto.CurrentUrl());	
		
		String NewUrl = auto.CurrentUrl();
		
		Assert.assertNotEquals(OldUrl, NewUrl);
	}
	
	@Test
	public void CopyText() {
		TestAutomation auto = new TestAutomation(driver);
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(auto.FirstFieldValue());
		
		auto.DoubleClickButton();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(auto.SecondFieldValue());
						
		SoftAssert softAssert = new SoftAssert();
				
		System.out.println(auto.FirstFieldValue().length());
				
		System.out.println(auto.SecondFieldValue().length());
						
		softAssert.assertEquals(auto.FirstFieldValue(), auto.SecondFieldValue());
										
		softAssert.assertAll();
	}
	
	@Test
	public void SliderTesting() {
		TestAutomation auto = new TestAutomation(driver);
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String FirstColor = auto.SliderColorWithoutClick();
		
		System.out.println(FirstColor);
				
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
						
		//auto.SliderClick();
		
		/*String SecondColor = auto.SliderColorWithoutClick();
 		
 		System.out.println(SecondColor);*/
 		
 		//

 		WebElement slider = driver.findElement(By.xpath("//span[@tabindex='0']"));
 		  String sliderValue = slider.getAttribute("style");

 	        // Print the slider's current value
 	     //   System.out.println("The slider's old current value is: " + sliderValue);
 		 System.out.println("The slider's old current value is: " + auto.SliderStyleValue());  
 		  
 		System.out.println("Vucem ga");
 		Actions move = new Actions(driver);
        Action action =  move.dragAndDropBy(slider, 200, 0).build();
        action.perform();
        
        auto.SliderMove();
 		
        try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        String SecondColor = auto.SliderColorWithoutClick();
 		
 		System.out.println(SecondColor);
        
        String sliderValue1 = slider.getAttribute("style");

        // Print the slider's current value
        System.out.println("The slider's current value is: " + sliderValue1);
        
		SoftAssert softAssert = new SoftAssert();
		
		softAssert.assertNotEquals(FirstColor, SecondColor);
		
		softAssert.assertNotEquals(sliderValue1, sliderValue);
		
		softAssert.assertAll();
	}
	
	//Dragovanje
	
	@Test
	public void Resizable() {
		TestAutomation auto = new TestAutomation(driver);
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SoftAssert softAssert = new SoftAssert();
				
		System.out.println(auto.HeaderSize());
			
		auto.DragDrop();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		System.out.println(auto.HeaderSize());
		
	}
	
	@Test
	public void DragingDroping() {
		TestAutomation auto = new TestAutomation(driver);
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SoftAssert softAssert = new SoftAssert();
				
		System.out.println(auto.DropableText());
		System.out.println(auto.DropableColor());
				
		auto.DragDrop();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(auto.DropableText());
		System.out.println(auto.DropableColor());
		
	}
		
	////button[@onclick='myFunctionAlert()']
	
	@Test
	public void JSAlertTestingAccept() {
		TestAutomation auto = new TestAutomation(driver);
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SoftAssert softAssert = new SoftAssert();
				
		System.out.println(auto.AlertButtons());
						
	for(int i=1; i<=auto.AlertButtons(); i++) {
		driver.findElement(By.xpath("((//div[@class='widget HTML']/div)[7]/button)["+i+"]")).click();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.switchTo().alert().accept();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		softAssert.assertFalse(auto.AlertAfterClick().isEmpty(), "URL does not contain the expected text!");
			//System.out.println(AcceptText);
		
	}
		
	softAssert.assertAll();
	
	}
	
	@Test
	public void JSAlertTestingCancel() {
		TestAutomation auto = new TestAutomation(driver);
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SoftAssert softAssert = new SoftAssert();
				
		System.out.println(auto.AlertButtons());
				
	for(int i=2; i<=auto.AlertButtons(); i++) {
		driver.findElement(By.xpath("((//div[@class='widget HTML']/div)[7]/button)["+i+"]")).click();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.switchTo().alert().dismiss();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String CancelButton = "Cancel";
	
	softAssert.assertTrue(auto.AlertAfterClick().toLowerCase().contains(CancelButton.toLowerCase()), "URL does not contain the expected text!");
	}
		
	softAssert.assertAll();
	
		}
	
	@Test
	public void JSAlertTestingInsertText() {
		TestAutomation auto = new TestAutomation(driver);
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SoftAssert softAssert = new SoftAssert();
				
		System.out.println(auto.AlertButtons());
				
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	String SendText = "Text";
	auto.PromptButtonClick();
	driver.switchTo().alert().sendKeys(SendText);
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	driver.switchTo().alert().accept();
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	softAssert.assertTrue(auto.AlertAfterClick().toLowerCase().contains(SendText.toLowerCase()), "URL does not contain the expected text!");
	
	softAssert.assertAll();
	
		}
	
	@Test
	public void SearchField() {
		TestAutomation auto = new TestAutomation(driver);
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String OldUrl = driver.getCurrentUrl();
		
		System.out.println(driver.getCurrentUrl());
		
		SoftAssert softAssert = new SoftAssert();
				
		auto.SearchField();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	System.out.println(auto.ErrorMethod());
	
	softAssert.assertEquals(auto.ErrorMethod(), "Please enter text to search.");
	
	auto.SearchFieldSend();
	
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	auto.SearchResultNumber();
	 
	auto.SearchMore();
	
	 try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 
	 auto.SwitchToNewWindow();
	 
	 String NewUrl = driver.getCurrentUrl();
	 
	 System.out.println(driver.getCurrentUrl());
	 
	 softAssert.assertNotEquals(OldUrl, NewUrl);
	 
	softAssert.assertAll();
	}
	
	@Test
	public void Forms() {
		TestAutomation auto = new TestAutomation(driver);
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SoftAssert softAssert = new SoftAssert();
				
		System.out.println(auto.NumberRadioButtons());
		for( WebElement i: auto.ListOfRadioButtons()){ //ListOfRadioButtons
	       // System.out.println(i.getText());
			i.click();
			softAssert.assertTrue(i.isSelected());
		}
				
		int WeekNumber = auto.WeekDays().size();  
		System.out.println(WeekNumber);
		for( WebElement i: auto.WeekDays()){
	        System.out.println(i.getText());
	        String DayText = i.getText();
	        softAssert.assertTrue(DayText.length() > 0);
		}
		
		//		
		softAssert.assertNotNull(auto.CountryList());
		softAssert.assertNotNull(auto.NumberOfCountries() > 1);
	
		for( WebElement i: auto.ListColor()){
	        System.out.println(i.getText());
	        softAssert.assertNotNull(i);
		}
		
	
		auto.SendText();
	
		auto.RadioMale().click();
	
		softAssert.assertTrue(auto.RadioMale().isSelected());
	
		auto.RadioFemale().click();
		
		softAssert.assertTrue(auto.RadioFemale().isSelected());
		auto.SelectCountry();
		auto.SelectColor();
		auto.PickDate();	
		auto.OpenCartClick();
		driver.navigate().back();	
		auto.OrangeHRMClick();
		softAssert.assertAll();
	}
	
	@Test
	public void WebTable() {
		TestAutomation auto = new TestAutomation(driver);
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SoftAssert softAssert = new SoftAssert();
			
	String FontSize =	auto.WebTableRow().getCssValue("font-size");
	String FontFamily =	auto.WebTableRow().getCssValue("font-family");
	String FontColor =	auto.WebTableRow().getCssValue("color");
	String FontWeight =	auto.WebTableRow().getCssValue("font-weight");
	
	
	int FontSizeNumber = Integer.parseInt(FontWeight);
	
	WebElement FontWeightElement =	driver.findElement(By.xpath("//table[@name='BookTable']/tbody/tr"));
	
	JavascriptExecutor js = (JavascriptExecutor) driver;
    String fontWeight = (String) js.executeScript("return window.getComputedStyle(arguments[0], null).getPropertyValue('font-weight');", FontWeightElement);

    // Output the font-weight
    System.out.println("Computed Font Weight: " + fontWeight);
	System.out.println(FontSize+ " Font Family "+FontFamily+" Font Color "+FontColor+"Font Bold"+FontWeight);
	
	String FontSize2 =	auto.WebTableSecondRow().getCssValue("font-size");
	String FontFamily2 = auto.WebTableSecondRow().getCssValue("font-family");
	String FontColor2 =	auto.WebTableSecondRow().getCssValue("color");
	String FontWeight2 = auto.WebTableSecondRow().getCssValue("font-weight");
		
	
	System.out.println(FontSize2+ " Font Family "+FontFamily2+" Font Color "+FontColor2+" Font Weight "+FontWeight2 );

	if(FontSizeNumber == 400) {
		System.out.println("Right one");
		softAssert.assertEquals(FontSizeNumber, 400);
	}else {
		System.out.println("not true");
	}
	
	if(FontSizeNumber == 700) {
		System.out.println("Bold");
		softAssert.assertEquals(FontSizeNumber, 700);
	}else {
		System.out.println("Not Bold");
	}
	
	List<WebElement> ListSearchResults	= driver.findElements(By.xpath("//table[@name='BookTable']/tbody/tr"));
	int SearchResultNumber = ListSearchResults.size();
	
	int RowItemsNumber = SearchResultNumber - 1;
	
	System.out.println(SearchResultNumber);
	
//	  for( WebElement i: ListSearchResults){
//	         System.out.println(i.getText());
	//  }
	  
	//Proveri ko je bold a koji nije po weight
	  for(int i = 1; i < SearchResultNumber; i++) {
		  String FontWeightItem = driver.findElement(By.xpath("(//table[@name='BookTable']/tbody/tr)["+i+"]")).getCssValue("font-weight");
		  int FontWeightNumber = Integer.parseInt(FontWeightItem);
		  System.out.println(FontWeightItem);
		  if(FontSizeNumber == 700) {
				System.out.println("Bold");
				softAssert.assertEquals(FontSizeNumber, 700);
			}else {
				System.out.println("Not Bold");
			}
	  }
	
	  driver.findElement(By.xpath("(//table[@name='BookTable']/tbody/tr)[1]/th"));
	
	  System.out.println("Column Number "+auto.ColumnNumber());
		
	softAssert.assertAll();
	
	}
	
	@Test
	public void PaginationTable() {
		TestAutomation auto = new TestAutomation(driver);
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SoftAssert softAssert = new SoftAssert();
				 
		// ovde gledaj da se pobroji cells u redu posto je jedan takav
		
		  System.out.println("Column Number "+auto.PaginationColumnNumber());
						
		// ovde su ostali redovi 
		
		  System.out.println("List Row Number "+auto.PaginationRowNumber());
		
		  //paginacija
	
		  System.out.println("List Pagination Number "+auto.ListPaginationNumber());
		driver.findElement(By.xpath("//ul/li"));
		
		driver.findElement(By.xpath("(//table[@id='productTable']/tbody/tr)[1]/td[4]/input"));  
		// checkboxovi
	  System.out.println("Broj Checkboxova "+auto.ListPaginationCheckbox());
				  
		
		 
		 auto.CheckboxClicked();
		 				 
		 //
		
		 System.out.println("Background color: " + auto.PaginationColorFirstPage());
		 //
						 
		 System.out.println("Background color2: " + auto.PaginationColorSecondPage());
		 //
		 String backgroundColor2 = auto.PaginationColorSecondPage();
		 			
		 System.out.println(auto.ListNumbersButton());
		 		 
		 for(int j=1; j<=auto.ListNumbersButton(); j++) {
			 driver.findElement(By.xpath("(//ul/li/a)["+j+"]")).click();
			 JavascriptExecutor jse = (JavascriptExecutor) driver;
			 WebElement ForBackgroundColor = driver.findElement(By.xpath("(//ul/li/a)["+j+"]"));
			 String backgroundColorForElement = (String) jse.executeScript(
			         "return window.getComputedStyle(arguments[0], null).getPropertyValue('background-color');",
			         ForBackgroundColor
			 );
			 System.out.println(backgroundColorForElement);
			 softAssert.assertNotEquals(backgroundColorForElement, backgroundColor2);						 
		 }
		 		 
		 softAssert.assertAll(); 
		 
	}  
	
	@Test
	public void PaginationTableEachrow() {
		TestAutomation auto = new TestAutomation(driver);
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SoftAssert softAssert = new SoftAssert();
				
		 for(int j=1; j<=auto.ListNumbersButton(); j++) {
			 WebElement GetElementsRow = driver.findElement(By.xpath("(//table[@id='productTable']/tbody/tr)["+j+"]/td"));
			 List<WebElement> ListCels = driver.findElements(By.xpath("(//table[@id='productTable']/tbody/tr)["+j+"]/td"));
			  int ListNumbersCells = ListCels.size();
			 System.out.println(ListNumbersCells);
			 
			 try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 driver.findElement(By.xpath("(//ul/li/a)["+j+"]")).click();			 
			 
		 }
		
	}
	
}
