package PageObjectModel.PageObjectModel;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.time.format.DateTimeFormatter;

public class Dashboard {

	WebDriver driver;
	
	public Dashboard(WebDriver driver) {
		this.driver = driver;
	}
	
	By SmallTime = By.xpath("//p[@class='oxd-text oxd-text--p orangehrm-attendance-card-fulltime']");
	
	By BigTime = By.xpath("//span[@class='oxd-text oxd-text--span orangehrm-attendance-card-fulltime']");
	
	By RemainingPath = By.xpath("(//div[@class='orangehrm-todo-list-item']/p)[1]");
	
	By AfterActionOpens = By.xpath("(//span[@class='oxd-text oxd-text--span'])[1]");
	
	By ToDoItem = By.xpath("//div[@class='orangehrm-todo-list-item']");
	
	By CardPost = By.xpath("//div[@class='oxd-grid-item oxd-grid-item--gutters orangehrm-buzz-widget-card']");
	
	By QuickLaunchIcons = By.xpath("//div[@class='oxd-grid-item oxd-grid-item--gutters orangehrm-quick-launch-card']");
	
	By QuickLaunchCard = By.xpath("//div[@class='oxd-grid-item oxd-grid-item--gutters orangehrm-quick-launch-card']");
	
	By WorkPlace = By.xpath("//ul[@class='oxd-chart-legend']/li");
	
	public String SmallTimeResult() {
	 String SmallerTime = driver.findElement(SmallTime).getText();
	 return SmallerTime;
	}
	
	public String BigTimeResult() {
	 String BiggerTime = driver.findElement(BigTime).getText();
	 return BiggerTime;
	}
	
	public int RemainingNumber() {
		String testni = driver.findElement(RemainingPath).getText();
		String ready = testni.substring(testni.indexOf('(') + 1, testni.indexOf(')'));	
		int readynum = Integer.parseInt(ready);
		return readynum;
	}
	
	public int RemainingNumberAfterActionOpens() {
		String testni = driver.findElement(AfterActionOpens).getText();
		String ready = testni.substring(testni.indexOf('(') + 1, testni.indexOf(')'));	
		int readynum = Integer.parseInt(ready);
		return readynum;
	}
	
	public String RemainingText() {
		String testni = driver.findElement(RemainingPath).getText();
	//	String last = testni.substring(testni.lastIndexOf(' ') + 1);
	//	double readynum = Double.parseDouble(last);
		String last = testni.substring(testni.indexOf(' ') + 1);
		return last;
	}
	
	public int MyActionsToDoNumber() {
		List<WebElement> lst = driver.findElements(ToDoItem);
		int TotalNumber = lst.size();
		return TotalNumber;
	}
	
	public WebElement PresentElement() {
		WebElement element = driver.findElement(ToDoItem);
		return element;
	}
	
	public int PostCardNumbers() {
		List<WebElement> lst = driver.findElements(CardPost);
		int TotalCardNumber = lst.size();
		return TotalCardNumber;
	}
	
	public int QuickLaunchNumberIcons() {
		List<WebElement> lst = driver.findElements(QuickLaunchIcons);
		int TotalIconNumbers = lst.size();
		return TotalIconNumbers;
	}
	
	public int QuickLaunchNumberCards() {
		List<WebElement> lst = driver.findElements(QuickLaunchCard);
		int TotalIconNumbers = lst.size();
		return TotalIconNumbers;
	}
	
	public int EmployeeDistribution() {
		List<WebElement> ListElements = driver.findElements(WorkPlace);
		int TotalNumberWorkPlaces = ListElements.size();
		return TotalNumberWorkPlaces;
	}
}
