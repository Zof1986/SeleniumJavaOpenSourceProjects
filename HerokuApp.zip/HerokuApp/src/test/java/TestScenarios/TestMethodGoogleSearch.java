package TestScenarios;

import static org.testng.Assert.assertNotEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Object.GoogleSearch;
import PageObjectModel.PageObjectModel.TestAutomation;
import io.github.bonigarcia.wdm.WebDriverManager;

public class TestMethodGoogleSearch {

	WebDriver driver;
	
	@BeforeTest
	public void beforetest() {
		WebDriverManager.chromedriver().driverVersion("125.0.6422.60").setup();
		driver = new ChromeDriver();
		
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		 
	}
		
	//https://the-internet.herokuapp.com//
	
	@Test
	public void AddDelete() {
		driver.get("https://the-internet.herokuapp.com");	
		driver.findElement(By.xpath("//a[text()='Add/Remove Elements']")).click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SoftAssert softAssert = new SoftAssert();
		
		WebElement AddButton = driver.findElement(By.xpath("//button[text()='Add Element']"));
		
		softAssert.assertTrue(AddButton.isDisplayed());
		
		driver.findElement(By.xpath("//button[text()='Add Element']")).click();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		WebElement DeleteButton = driver.findElement(By.xpath("//button[text()='Delete']"));
	
		softAssert.assertTrue(DeleteButton.isDisplayed());
		
		driver.findElement(By.xpath("//button[text()='Delete']")).click();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//softAssert.assertTrue(DeleteButton.isDisplayed());
		try {
			WebElement DeleteButton1 = driver.findElement(By.xpath("//button[text()='Delete']"));
			
		softAssert.fail("Element should not be present on the page.");
		 } catch (NoSuchElementException e) {
             // If NoSuchElementException is caught, the element is not present
             System.out.println("Element is not present as expected.");
         }
		
		softAssert.assertAll();
	}

	@Test
	public void BrokenImages() {
		driver.get("https://the-internet.herokuapp.com");	
		driver.findElement(By.xpath("//a[text()='Broken Images']")).click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SoftAssert softAssert = new SoftAssert();
				
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	//	softAssert.assertTrue(DeleteButton.isDisplayed());
			
	WebElement Image = driver.findElement(By.xpath("//div/img"));
	
	List<WebElement> ListImages = driver.findElements(By.xpath("//div/img"));
	int ImageNumber = ListImages.size();
				
	for(int i = 1; i<=ListImages.size(); i++) {
		WebElement SourceList =	driver.findElement(By.xpath("(//div/img)["+i+"]"));
		//softAssert.assertTrue("Element should be visible",SourceList.isDisplayed());
		softAssert.assertTrue(SourceList.isDisplayed(), "Another Element should be present");
	}
		
	//WebElement Source = driver.findElement(By.xpath("(//div/img)[1]"));
	//System.out.println(Source.getAttribute("src"));
	
	for(int i = 1; i<=ListImages.size(); i++) {
		WebElement SourceList =	driver.findElement(By.xpath("(//div/img)["+i+"]"));
		System.out.println(SourceList.getAttribute("src"));
		String SourceText = SourceList.getAttribute("src");
		softAssert.assertTrue(SourceText.contains("/img"), "image "+ i +" is broken");
	}
		
	System.out.println(ImageNumber);
		
		softAssert.assertAll();
	}

	@Test
	public void DOMelements() {
		driver.get("https://the-internet.herokuapp.com");	
		driver.findElement(By.xpath("//a[text()='Challenging DOM']")).click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SoftAssert softAssert = new SoftAssert();
				
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Number of buttons
		driver.findElement(By.xpath("//div[@class='large-2 columns']/a"));
		
		List<WebElement> ListColorButtons = driver.findElements(By.xpath("//div[@class='large-2 columns']/a"));
		int ButtonNumber = ListColorButtons.size();
		
		System.out.println(ButtonNumber);
		
		//Background color of buttons
		for(int i = 1; i<=ButtonNumber; i++) {
		String Color = driver.findElement(By.xpath("(//div[@class='large-2 columns']/a)["+i+"]")).getCssValue("background-color");
		System.out.println(Color);
		}
			
	//String ButtonText =	driver.findElement(By.xpath("//div[@class='large-2 columns']/a")).getText();
	//System.out.println(ButtonText);
	
		
		//Show text of buttons 
		List<String> Buttonlist = new ArrayList<>();
		//list.add('Hello');
	for(int i = 1; i<=ButtonNumber; i++) {
		String Text = driver.findElement(By.xpath("(//div[@class='large-2 columns']/a)["+i+"]")).getText();
		System.out.println(Text);
		Buttonlist.add(Text);
		}
	
	 for (String element : Buttonlist) {
         System.out.println(element);
     }
	
	 /////check if buttons change text after clicking
	 	
	 	String ButText1 = driver.findElement(By.xpath("((//div[@class='large-2 columns']/a))[1]")).getText();
		
	 	try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 	
	 	driver.findElement(By.xpath("((//div[@class='large-2 columns']/a))[1]")).click();
	 
	 	String ButText2 = driver.findElement(By.xpath("((//div[@class='large-2 columns']/a))[1]")).getText();
		
	 	WebElement AllButtons = driver.findElement(By.xpath("//div[@class='large-2 columns']/a"));
	 	List<WebElement> ListOfAllButtons = driver.findElements(By.xpath("//div[@class='large-2 columns']/a"));
		int AllButtonsAll = ListOfAllButtons.size();
	 	
	 	System.out.println(ButText1 +" "+ButText2);
	 	
	 	System.out.println("Now Print last changes");
	 	
	 	for(int z=1; z<=AllButtonsAll;z++) {
	 	String FirstButton = driver.findElement(By.xpath("(//div[@class='large-2 columns']/a)["+z+"]")).getText();
	 	try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 	int FirstSize = FirstButton.length();
	 	driver.findElement(By.xpath("(//div[@class='large-2 columns']/a)["+z+"]")).click();
	 	try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 	String SecondButton = driver.findElement(By.xpath("(//div[@class='large-2 columns']/a)["+z+"]")).getText();
	 	try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 	int SecondSize = SecondButton.length();
	 	System.out.println(FirstButton +" "+SecondButton);
		softAssert.assertTrue(FirstSize == 3);
	 	softAssert.assertTrue(SecondSize == 3);
	 	}
	 	
	 	//
	 	System.out.println("cackam deo");
	 	for(int z=1; z<=AllButtonsAll;z++) {
		 	String NewFirstButton = driver.findElement(By.xpath("(//div[@class='large-2 columns']/a)["+z+"]")).getText();
		 	System.out.println(NewFirstButton);
		 	try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 	driver.findElement(By.xpath("(//div[@class='large-2 columns']/a)["+z+"]")).click();
		 	try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 	String NewSecondButton = driver.findElement(By.xpath("(//div[@class='large-2 columns']/a)["+z+"]")).getText();
		 	System.out.println(NewSecondButton); 
		 //	softAssert.assertFalse(NewFirstButton.contains(NewSecondButton));
		 	softAssert.assertNotEquals(NewFirstButton, NewSecondButton, "The text has not changed");
	 	}
	 	
	 	//
	 	
	 	
	 
	 	//WebElement HeadRow = driver.findElement(By.xpath("//table/thead/tr/th"));
	 	List<WebElement> ListHedRowCells = driver.findElements(By.xpath("//table/thead/tr/th"));
		int NumberOfCells = ListHedRowCells.size();
		System.out.println("Number of top Cells "+NumberOfCells);
	 	
		////tbody/tr
		List<WebElement> ListRowCells = driver.findElements(By.xpath("//tbody/tr"));
		int NumberOfRows = ListRowCells.size();
		System.out.println("Number of Rows "+NumberOfRows);
		
		////tbody/tr/td/a[text()='edit']
		
		driver.findElement(By.xpath("//tbody/tr/td/a[text()='edit']")).click();
		String EditClick = driver.getCurrentUrl();
		
		///
		driver.findElement(By.xpath("//tbody/tr/td/a[text()='delete']")).click();
		String DeleteClick = driver.getCurrentUrl();
		
	 	softAssert.assertAll();
	}
	
	@Test
	public void Checkboxes() {
		driver.get("https://the-internet.herokuapp.com");	
		driver.findElement(By.xpath("//a[text()='Checkboxes']")).click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SoftAssert softAssert = new SoftAssert();
		
		WebElement checkbox1 = driver.findElement(By.xpath("(//input)[1]"));
				
		WebElement checkbox2 = driver.findElement(By.xpath("(//input)[2]"));
	
		checkbox1.click();
		
		checkbox2.click();
		
		softAssert.assertTrue(checkbox1.isSelected(),"Not Selected checkbox1");
		
		softAssert.assertTrue(checkbox2.isSelected(),"Not Selected checkbox2");
		
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		checkbox1.click();
		
		checkbox2.click();
		
		softAssert.assertTrue(checkbox1.isSelected(),"Not selected checkbox1");
				
		softAssert.assertTrue(checkbox2.isSelected(),"Not selected checkbox2");
		
		softAssert.assertAll();
	}
	
	@Test
	public void ContextMenu() {
		driver.get("https://the-internet.herokuapp.com");	
		driver.findElement(By.xpath("//a[text()='Context Menu']")).click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SoftAssert softAssert = new SoftAssert();
		
		Actions action = new Actions(driver);

		WebElement link = driver.findElement(By.xpath("//div[@id='hot-spot']"));
		action.contextClick(link).perform();
		String AlertText = driver.switchTo().alert().getText();
		
		driver.switchTo().alert().accept();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	//	action.click(link).perform();
		
		System.out.println(AlertText);
		
		softAssert.assertTrue(AlertText.length() > 0);
		
		softAssert.assertAll();
	}
	
	@Test
	public void DissappearingElements() {
		driver.get("https://the-internet.herokuapp.com");	
		driver.findElement(By.xpath("//a[text()='Disappearing Elements']")).click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SoftAssert softAssert = new SoftAssert();
		
		driver.findElement(By.xpath("//ul/li"));
		
		List<WebElement> ListElements = driver.findElements(By.xpath("//ul/li"));
		int NumberElements = ListElements.size();
		System.out.println("Number of elements"+NumberElements);
		
		Actions action = new Actions(driver);

		WebElement link = driver.findElement(By.xpath("(//ul/li/a)[1]"));
		
		String beforeHovering = driver.findElement(By.xpath("(//ul/li/a)[1]")).getCssValue("color");
		
		System.out.println(beforeHovering);
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 action.moveToElement(link).perform();
		 
		 String ColorMouse = link.getCssValue("color");
		 
		 System.out.println(ColorMouse);
	}
	
}
