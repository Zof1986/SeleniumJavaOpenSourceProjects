package PageObjectModel.PageObjectModel;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;

public class TestAutomation {

WebDriver driver;
	
    By NewBrowserWindow = By.xpath("//button[@onClick='myFunction()']");
    
    By DoubleClick = By.xpath("//button[@ondblclick='myFunction1()']");
    
    By FirstField = By.xpath("//input[@id='field1']");
	
    By SecondField = By.xpath("//input[@id='field2']");
    
    By Slider = By.xpath("//span[@tabindex='0']");
    
    By AlertButton = By.xpath("(//div[@class='widget HTML']/div)[7]/button");
    
    By AlertText = By.xpath("//p[@id='demo']");
    
    By PromptButton = By.xpath("//button[text()='Prompt']");
    
    By SliderElement = By.xpath("//span[@tabindex='0']");
    
    By DropableElement = By.xpath("//div[@id='droppable']/p");
    
    By DragableElement = By.xpath("//div[@id='draggable']");
    
    By DragingElement = By.xpath("//div[@class='ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se']");

    By HeaderElement = By.xpath("//div/h3");
    
    By SearchWiki = By.xpath("//input[@id='Wikipedia1_wikipedia-search-input']");
    
    By Error = By.xpath("//div[@id='Wikipedia1_wikipedia-search-results']");
    
    By ItemResult = By.xpath("//div[@id='Wikipedia1_wikipedia-search-results']/div");
    
    By SearchMore = By.xpath("//div[@id='Wikipedia1_wikipedia-search-more']/a");
    
    By RadioButton = By.xpath("(//div[@class='form-group'])[4]/div/input");
    
    By MaleRadio = By.xpath("//input[@id='male']");
    
    By FemaleRadio = By.xpath("//input[@id='female']");
    
    By WeekDay = By.xpath("//div[@class='form-check form-check-inline']");
    
    By Country = By.xpath("//select[@id='country']/option");
    
    By ColorList = By.xpath("//select[@class='form-control']/option");
    
    By Name = By.xpath("//input[@id='name']");
    
    By Email = By.xpath("//input[@id='email']");
    
    By Phone = By.xpath("//input[@id='phone']");
    		
    By Address = By.xpath("//div[@class='form-group']/textarea");		
    
    By CountryDropdown = By.xpath("//select[@id='country']");
    
    By CountryItem = By.xpath("(//select[@id='country']/option)[2]");
    
    By ColorItem = By.xpath("(//select[@class='form-control']/option)[13]");
    
    By DatePicker = By.xpath("//input[@id='datepicker']");
    
    By DateChoosen = By.xpath("((//table[@class='ui-datepicker-calendar'])[1]/tbody/tr/td)[5]");
	    
    By OpenCart = By.xpath("//*[text()='open cart          ']");
    
    By OrangeHRM = By.xpath("//*[text()='orange HRM']");
    
    By WebRow = By.xpath("//table[@name='BookTable']/tbody/tr");
    
    By WebSecondRow = By.xpath("//table[@name='BookTable']/tbody/tr");
    
    By Cell = By.xpath("(//table[@name='BookTable']/tbody/tr)[1]/th");
    
    By PaginationCell =By.xpath("//table[@id='productTable']/thead/tr/th");
    
    By PaginationRow = By.xpath("//table[@id='productTable']/tbody/tr");
    
    By PaginationList = By.xpath("//ul/li");
    
    By PaginationCheckboxElement = By.xpath("(//table[@id='productTable']/tbody/tr)/td[4]");
    
    By CheckBox = By.xpath("(//table[@id='productTable']/tbody/tr)/td[4]/input");
    
    By FirstPaginationPageColor = By.xpath("//ul/li/a");
    
    By SecondPaginationPageColor = By.xpath("(//ul/li/a)[2]");
    
	public TestAutomation(WebDriver driver) {
		this.driver=driver;
	}
	
	public String CurrentUrl() {
		String Url = driver.getCurrentUrl();
		return Url;
	}
	
	public void ClickNewBrowserButton() {
		
	driver.findElement(NewBrowserWindow).click();
	
	}
	
	public void SwitchToNewWindow() {
		Set<String> windowIds = driver.getWindowHandles();
		
		for(String windowId : windowIds) {
			driver.switchTo().window(windowId);
		}
	}
	
	public void DoubleClickButton() {
		WebElement Button =	driver.findElement(DoubleClick);
		
		Actions act = new Actions(driver);
		
		act.doubleClick(Button).perform();
	}
	
	public void SliderMove() {
		WebElement Slider = driver.findElement(SliderElement);
		String SliderValue = Slider.getAttribute("style");
		Actions move = new Actions(driver);
        Action action =  move.dragAndDropBy(Slider, 200, 0).build();
        action.perform();
	}
	
	public String SliderStyleValue() {
	WebElement slider = driver.findElement(By.xpath("//span[@tabindex='0']"));
	String sliderValue = slider.getAttribute("style");
	return sliderValue;
	}
	  
	public String FirstFieldValue() {
	 String FirstValue = driver.findElement(FirstField).getAttribute("value");
	 return FirstValue;
	}
	
	public String SecondFieldValue() {
		 String SecondValue = driver.findElement(SecondField).getAttribute("value");
		 return SecondValue;
		}
	
	public String SliderColorWithoutClick() {
		String color = driver.findElement(Slider).getCssValue("background");
		//String hex = Color.fromString(color).asHex();
		String[] SplitValue = color.split("none");
		String bgColor = SplitValue[0];
 		String hex = Color.fromString(bgColor).asHex();
 		return hex;
	}
	
	public void SliderClick() {
		driver.findElement(Slider).click();
	}
	
	public int AlertButtons() {
		List<WebElement> ListAlertButtons = driver.findElements(AlertButton);
		int ALertButtonNumber = ListAlertButtons.size();
		return ALertButtonNumber;
	}
	
	public String AlertAfterClick() {
		String AcceptText =	driver.findElement(AlertText).getText();
		return AcceptText;
	}
	
	public void PromptButtonClick() {
		driver.findElement(PromptButton).click();
	}
	
	//System.out.println(driver.findElement(By.xpath("//div[@id='droppable']/p")).getText());
	//System.out.println(driver.findElement(By.xpath("//div[@id='droppable']/p")).getCssValue("color"));
	
	public String DropableText() {
	String Text = driver.findElement(DropableElement).getText();
	return Text;
	}
	
	public String DropableColor() {
	String Color = driver.findElement(DropableElement).getCssValue("color");
	return Color;
	}
	
	public void DragDrop() {
		
		Actions act = new Actions(driver);	
		WebElement element = driver.findElement(DragingElement);
		act.dragAndDropBy(element, -200, -200).perform();
	}
	
	public Dimension HeaderSize() {
		Dimension ElementSize = driver.findElement(HeaderElement).getSize();
		return ElementSize;
	}
	
	public void SearchField() {
		driver.findElement(SearchWiki).sendKeys(Keys.SPACE);
		driver.findElement(SearchWiki).sendKeys(Keys.ENTER);		
	}
	
	public String ErrorMethod() {
		String ErrorText =	driver.findElement(Error).getText();
		return ErrorText;
	}
	
	public void SearchFieldSend() {
		driver.findElement(SearchWiki).sendKeys("first");
		driver.findElement(SearchWiki).sendKeys(Keys.ENTER);		
	}
	
	public void SearchResultNumber() {
		WebElement SearchResult = driver.findElement(ItemResult);
		List<WebElement> ListSearchResults	= driver.findElements(ItemResult);
		int SearchResultNumber = ListSearchResults.size();
		
		System.out.println(SearchResultNumber);
		
		  for( WebElement i: ListSearchResults){
		         System.out.println(i.getText());
		  }
	}
	
	public void SearchMore() {
		driver.findElement(SearchMore).click();
	}
	
	public WebElement RadioMale() {
		WebElement RadioButtonMale = driver.findElement(MaleRadio);	
		return RadioButtonMale;
	}
	
	public WebElement RadioFemale() {
		WebElement RadioButtonFemale = driver.findElement(FemaleRadio);		
		return RadioButtonFemale;
	}
		
	public List<WebElement> ListOfRadioButtons() {
		List<WebElement> RadioDays = driver.findElements(RadioButton);
		return RadioDays;
	}
	
	public int NumberRadioButtons() {
		List<WebElement> RadioDays = driver.findElements(RadioButton);
		int RadioNumber = RadioDays.size();
		return RadioNumber;
	}
	
	public List<WebElement> WeekDays() {
		List<WebElement> WeekDays = driver.findElements(WeekDay);
		return WeekDays;
	}
	
	public List<WebElement> CountryList() {
		List<WebElement> ListCountry = driver.findElements(Country);
		return ListCountry;
	}
	
	public int NumberOfCountries() {
		List<WebElement> ListCountry = driver.findElements(Country);
		int CountryNumber = ListCountry.size();
		return CountryNumber;		
	}
	
	public int ListColorNumber() {
		List<WebElement> ListColor = driver.findElements(ColorList);
		int ColorNumber = ListColor.size();
		return ColorNumber;
	}
	
	public List<WebElement> ListColor() {
		List<WebElement> ListColor = driver.findElements(ColorList);
		return ListColor;
	}
	
	public void SendText() {
		driver.findElement(Name).sendKeys("test");
		driver.findElement(Email).sendKeys("test");
		driver.findElement(Phone).sendKeys("test");
		driver.findElement(Address).sendKeys("test");		
	}
	
	public void SelectCountry() {
		driver.findElement(CountryDropdown).click();
		driver.findElement(CountryItem).click();
	}
	
	public void SelectColor() {
		driver.findElement(ColorItem).click();
	}
	
	public void PickDate() {
		driver.findElement(DatePicker).click();
		driver.findElement(DateChoosen).click();	
	}
	
	public void OpenCartClick() {
		driver.findElement(OpenCart).click();
	}
	
	public void OrangeHRMClick() {
		driver.findElement(OrangeHRM).click();
	}
	
	public WebElement WebTableRow() {
		WebElement TableRow = driver.findElement(WebRow);
		return TableRow;
	}
	
	public WebElement WebTableSecondRow() {
		WebElement TableRow = driver.findElement(WebSecondRow);
		return TableRow;
	}
	
	public int ColumnNumber() {
		  List<WebElement> ListColumnNumbers = driver.findElements(Cell);
		  int ColumnNumbers = ListColumnNumbers.size();
		  return ColumnNumbers;
	}
	
	public int PaginationColumnNumber() {
		 List<WebElement> ListCellRows = driver.findElements(PaginationCell);
		  int ColumnNumbers = ListCellRows.size();
		  return ColumnNumbers;
	}
	
	public int PaginationRowNumber() {
		List<WebElement> ListRows = driver.findElements(PaginationRow);
		int ListRowsNumbers = ListRows.size();
		return ListRowsNumbers;
	}
	
	public int ListPaginationNumber() {
		  List<WebElement> ListPagination = driver.findElements(PaginationList);
		  int ListPaginationNumbers = ListPagination.size();
		  return ListPaginationNumbers;
	}
	
	public int ListPaginationCheckbox() {
		 List<WebElement> ListcheckBox = driver.findElements(PaginationCheckboxElement);  
		  int ListCheckboxNumbers = ListcheckBox.size();
		  return ListCheckboxNumbers;
	}
	
	public void CheckboxClicked() {
		 List<WebElement> CheckboxLists = driver.findElements(CheckBox);  
		  
		 for( WebElement i: CheckboxLists){
		        // System.out.println(i.getText());
			  i.click();
		  }
	}
	
	public String PaginationColorFirstPage() {
		 WebElement element = driver.findElement(FirstPaginationPageColor);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 String backgroundColor = (String) js.executeScript(
		         "return window.getComputedStyle(arguments[0], null).getPropertyValue('background-color');",
		         element
		 );
		 return backgroundColor;
	}
	
	public String PaginationColorSecondPage() {
		 WebElement element = driver.findElement(SecondPaginationPageColor);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 String backgroundColor = (String) js.executeScript(
		         "return window.getComputedStyle(arguments[0], null).getPropertyValue('background-color');",
		         element
		 );
		 return backgroundColor;
	}
	
	public int ListNumbersButton() {
		 List<WebElement> ListNumberPage = driver.findElements(By.xpath("//ul/li/a"));
		  int NumbersListButton = ListNumberPage.size();
		  return NumbersListButton;
	}
	
}
