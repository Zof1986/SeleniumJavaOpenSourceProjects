package PageObjectModel.PageObjectModel;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class Admin {

	WebDriver driver;
	
	public Admin(WebDriver driver) {
		this.driver = driver;
	}
	
	By RecordsPath = By.xpath("//span[@class='oxd-text oxd-text--span']");
		
	By SkillCard = By.xpath("//div[@class='oxd-table-card']");
	
	By EditButton = By.xpath("(//button)[5]");
	
	By UpperValue = By.xpath("(//input)[2]");
	
	By LowerValue = By.xpath("//textarea");
	
	By CancelButton = By.xpath("(//button)[3]");
	
	By ModuleTitle = By.xpath("//h6[@class='oxd-text oxd-text--h6 orangehrm-main-title']");
	
	By ItemInList = By.xpath("//ul[@class='oxd-dropdown-menu']/li/a");
	
	By HeaderDropdowns = By.xpath("//span[@class='oxd-topbar-body-nav-tab-item']");
	
	By SwitchBtn = By.xpath("//div[@class='orangehrm-module-field-row']");
	
	public int RecordsNumber() {
		String records = driver.findElement(RecordsPath).getText();		
		//	System.out.println(records);		
			String ready = records.substring(records.indexOf('(') + 1, records.indexOf(')'));	
			int readynum = Integer.parseInt(ready);
			return readynum;
	}
	
	public int SkillCardNumber() {
		int number = driver.findElements(SkillCard).size();
		return number;
	}
	
	public void EditButtonClick() {
		driver.findElement(EditButton).click();
	}
	
	public String UpperCardValue() {
		String value = driver.findElement(UpperValue).getAttribute("value");
		return value;
	}
	
	public String LowerCardValue() {
		String value1 = driver.findElement(LowerValue).getAttribute("value");
		return value1;
	}
	
	public void CardCancelButton() {
		driver.findElement(CancelButton).click();
	}
	
	public void EditButtonClicknew() {
		driver.findElement(CancelButton).click();
	}
	
	public String ModuleTitle() {
		String Title = driver.findElement(ModuleTitle).getText();
		return Title;
	}
	
	public int AdminNumberOfItemsInList() {
		List<WebElement> lst = driver.findElements(ItemInList);
		int TotalItemsInList = lst.size();
		return TotalItemsInList;
	}
	
	public int AdminNumberOfCharactersInItemInList() {
		String Text = driver.findElement(ItemInList).getText();
		int NumberOfText = Text.length();
		return NumberOfText;
	}
	
	public int AdminNumberOfHeadearDropdowns() {
		List<WebElement> lst = driver.findElements(HeaderDropdowns);
		int TotalDropdownsInHeader = lst.size();
		return TotalDropdownsInHeader;
	}
	
	public List<WebElement> ListSkillCard() {
		List<WebElement> elementsxpath = driver.findElements(SkillCard);
		return elementsxpath;
	}
	
	//div[@class='orangehrm-module-field-row']
	public List<WebElement> SwitchButtons() {
		List<WebElement> elementsxpath = driver.findElements(SkillCard);
		return elementsxpath;
	}
		
	public String SkillCardText() {
		String cardtext = driver.findElement(SwitchBtn).getText();
		return cardtext;
	}
	
}
