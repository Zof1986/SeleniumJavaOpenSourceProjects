package PageObjectModel.PageObjectModel;

import static org.testng.Assert.ARRAY_MISMATCH_TEMPLATE;
import static org.testng.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;
import jdk.internal.net.http.common.Log;

public class ClaimTest {

	WebDriver driver;
	
	@BeforeTest
	public void beforetest() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	@Test
	public void ClaimHeadersElements() {  //RTM 8......
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Claim claim = new Claim(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewAssignClaim");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
					
		SoftAssert softAssert = new SoftAssert();
		
			 
		for(int i = 1; i<=claim.ClaimNumberOfHeadearDropdowns(); i++) {
			
			driver.findElement(By.xpath("(//span[@class='oxd-topbar-body-nav-tab-item'])["+i+"]")).click();
			
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
									
			softAssert.assertTrue(claim.ClaimNumberOfItemsInList() > 0);
			
			softAssert.assertTrue(claim.ClaimNumberOfCharactersInItemInList() > 0);
				
		}
		softAssert.assertAll();
	}
	
	@Test
	public void ClaimReset() {  //RTM 8......
		//Razmisli jos malo o ovom
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Claim claim = new Claim(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewAssignClaim");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
					
	//	driver.findElement(By.xpath("(//input[@placeholder='Type for hints...'])[1]")).sendKeys("test");
	//	driver.findElement(By.xpath("(//input[@placeholder='Type for hints...'])[2]")).sendKeys("test");
		
		
		SoftAssert softAssert = new SoftAssert();
		
		
		String ValueOld = claim.EmployeeHint();
		System.out.println("Value of inserted text "+ValueOld);
		//claim.EmployeeHint();
		//System.out.println("Value of inserted text "+ValueOld);
		
		String ValueOldOld = claim.ReferenceId();
		System.out.println("Value of inserted text "+ValueOldOld);
		//claim.ReferenceId();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
	//	driver.findElement(By.xpath("(//button)[4]")).click();
		claim.ResetClick();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		//driver.findElement(By.xpath("(//button)[4]")).click();
		claim.ResetClick();
		
		String ValueNew = claim.EmployeeHint();
		System.out.println("Value of removed text "+ValueNew);
		
		String ValueNewNew = claim.ReferenceId();
		System.out.println("Value of removed text "+ValueNewNew);
		
		softAssert.assertEquals(ValueNew.length(), 0);
		softAssert.assertEquals(ValueNewNew.length(), 0);
		softAssert.assertNotEquals(ValueOld, ValueNew);
		softAssert.assertNotEquals(ValueOldOld, ValueNewNew);
		softAssert.assertAll();
		
	}
	
}