package PageObjectModel.PageObjectModel;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Performance {

	
WebDriver driver;
	
	public Performance(WebDriver driver) {
		this.driver = driver;
	}
	
	By SubmitButton = By.xpath("//button[@type='submit']");
	
	By Error = By.xpath("(//div/span)[2]");
	
	By TimeSheetRecordsRow = By.xpath("//div[@class='oxd-table-card']");
	
	By RemainingPath = By.xpath("//span[@class='oxd-text oxd-text--span']");
	
	By TableViewButton = By.xpath("//button[@class='oxd-button oxd-button--medium oxd-button--text oxd-table-cell-action-space']");
	
	By TotalDuration = By.xpath("//span[@class='oxd-text oxd-text--span orangehrm-header-total']");
	
	By AttendencieRow = By.xpath("//div[@class='orangehrm-attendance-field-row']");

	By SortIcon = By.xpath("//div[@class='oxd-table-header-sort']");
	
	By DescOrder = By.xpath("//i[@class='oxd-icon bi-sort-alpha-up']");
	
	By RowText = By.xpath("(//div[@class='oxd-table-card'])[1]");
	
	By Sort = By.xpath("(//div[@class='oxd-table-header-sort'])[2]");
	
	By Ascend = By.xpath("(//span[text()='Ascending'])[2]");
	
	By ItemInList = By.xpath("//ul[@class='oxd-dropdown-menu']/li/a");
	
	By HeaderDropdowns = By.xpath("//span[@class='oxd-topbar-body-nav-tab-item']");
	
	By View = By.xpath("//button[text()=' View ']");
	
	By AddLog = By.xpath("//button[text()=' Add Log ']");
	
	By Log = By.xpath("(//input)[2]");
	
	By Comment = By.xpath("//textarea");
	
	By PositiveLike = By.xpath("//button[@class='oxd-button oxd-button--medium oxd-button--text orangehrm-tracker-rating-button']");
	
	By Save = By.xpath("//button[text()=' Save ']");
	
	By FirstRowPath = By.xpath("//div[@class='oxd-sheet oxd-sheet--rounded oxd-sheet--gray-lighten-2 orangehrm-scroll-card']");
	
	By ThreeDots = By.xpath("(//button[@class='oxd-icon-button'])[2]");
	
	By ThreeDotsDelete = By.xpath("//p[text()='Delete']");
	
	By ConfirmDelete = By.xpath("//button[text()=' Yes, Delete ']");
	
	public void ViewButton() {
	driver.findElement(View).click();
	}
	
	public void AddLog() {
		driver.findElement(AddLog).click();
	}
	
	public void SubmitClick() {
		driver.findElement(SubmitButton).click();
	}
	
	public String Errortext() {
		return driver.findElement(Error).getText();
	}
	
	public int OptionFieldAss() {
		List<WebElement> lst = driver.findElements(TimeSheetRecordsRow);
		int OptNum = lst.size();
		return OptNum;
	}
	
	public int AttendencieWebElementSize() {
		List<WebElement> lst = driver.findElements(AttendencieRow);
		int OptNum = lst.size();
		return OptNum;
	}
	
	
	public int RemainingNumber() {
		String testni = driver.findElement(RemainingPath).getText();
		String ready = testni.substring(testni.indexOf('(') + 1, testni.indexOf(')'));	
		int readynum = Integer.parseInt(ready);
		return readynum;
	}
	
	public String LastNumber() {
		String testni = driver.findElement(TotalDuration).getText();
		String last = testni.substring(testni.lastIndexOf(' ') + 1);
	//	double readynum = Double.parseDouble(last);
		return last;
	}
	
		
	public int ViewButtonNumber() {
		List<WebElement> lst = driver.findElements(TableViewButton);
		int ViewNum = lst.size();
		return ViewNum;
	}	
	
	public void SortButtonClick() {
		driver.findElement(SortIcon).click();
	}
	
	public void DescendingOrder() {
		driver.findElement(DescOrder).click();
	}
	
	public String RowSorting() {
		String TextRow = driver.findElement(RowText).getText();
		return TextRow;
	}
	
	public int TotalRowSize() {
	   int Number =	driver.findElements(TimeSheetRecordsRow).size();
	   return Number;
	}
	
	public List<String> FirstList() {
		List<String> big  = new ArrayList<String>();
		return big;
	}
	
	public List<String> SecondList() {
		List<String> Omni  = new ArrayList<String>();
		return Omni;
	}
	
	public void Sorting() {
		driver.findElement(Sort).click();
	}
	
	public void Ascending() {
		driver.findElement(By.xpath("(//span[text()='Ascending'])[2]")).click();
	}
	
	public int PerformanceNumberOfItemsInList() {
		List<WebElement> lst = driver.findElements(ItemInList);
		int TotalItemsInList = lst.size();
		return TotalItemsInList;
	}
	
	public int PerformanceNumberOfCharactersInItemInList() {
		String Text = driver.findElement(ItemInList).getText();
		int NumberOfText = Text.length();
		return NumberOfText;
	}
	
	public int PerformanceNumberOfHeadearDropdowns() {
		List<WebElement> lst = driver.findElements(HeaderDropdowns);
		int TotalDropdownsInHeader = lst.size();
		return TotalDropdownsInHeader;
	}
	
	public void FormFilling() {
		driver.findElement(Log).sendKeys("Log test");
		
		driver.findElement(Comment).sendKeys("Comment test");
		
		driver.findElement(PositiveLike).click();
		
		driver.findElement(Save).click();
	}
	
	public String FirstRow() {
	WebElement FirstRow = driver.findElement(FirstRowPath);
	String NovaVrednost = FirstRow.getText();
	return NovaVrednost;
	}
	
	public WebElement FirstRowElement() {
		WebElement FirstRow = driver.findElement(FirstRowPath);
		return FirstRow;
	}
	
	public void ThreeDotsEditDelete() {
		driver.findElement(ThreeDots).click();
	}
	
	public void ThreeDotsDelete() {
		 driver.findElement(ThreeDotsDelete).click();
	}
	
	public void DeleteConfirm() {
		 driver.findElement(ConfirmDelete).click();
	}
	
	//https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewCandidates
	// pogledaj Candidates and Vacancies
	// ascending i descneind kada se napravi list onda mora da se vrsi neko sortiranje preko kolekcije istrazi
	
}
