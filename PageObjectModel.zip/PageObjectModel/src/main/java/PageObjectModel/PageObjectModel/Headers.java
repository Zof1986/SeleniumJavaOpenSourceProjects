package PageObjectModel.PageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Headers {

	WebDriver driver;
	
	public Headers(WebDriver driver) {
		this.driver = driver;
	}
	
	By Dropdown = By.xpath("//p[@class='oxd-userdropdown-name']");
	
	By AboutMelink = By.xpath("(//a[@class='oxd-userdropdown-link'])[1]");
	
	By AboutTitle = By.xpath("(//h6)[2]");
	
	By CompanyName = By.xpath("(//p[@class='oxd-text oxd-text--p orangehrm-about-text'])[1]");
	
	By Version = By.xpath("(//p[@class='oxd-text oxd-text--p orangehrm-about-text'])[2]");
	
	By ActiveEmployees = By.xpath("(//p[@class='oxd-text oxd-text--p orangehrm-about-text'])[3]");
	
	By SupportLink = By.xpath("(//a[@class='oxd-userdropdown-link'])[2]");
	
	By SupportTitle = By.xpath("(//h6)[2]");
	
	By SupportEmail = By.xpath("//a[@class='orangehrm-support-link']");
	
	By LogoutLink = By.xpath("(//a[@class='oxd-userdropdown-link'])[4]");
	
	By Search = By.xpath("//input");
	
	By SearchText = By.xpath("(//ul/li[@class='oxd-main-menu-item-wrapper'])[2]");
	
	By SearchNotFound = By.xpath("(//ul/li[@class='oxd-main-menu-item-wrapper'])[1]");
	
	public void DropdownClick() {
		driver.findElement(Dropdown).click();
	}
	
	public void DropdownClickABoutme() {
		driver.findElement(AboutMelink).click();
	}	
		
	public String AboutMeTitle() {
		return driver.findElement(AboutTitle).getText();
	}
	
	public String MyCompanyName() {
		return driver.findElement(CompanyName).getText();
	}
	
	public String VersionNumber() {
		return driver.findElement(Version).getText();
	}
	
	public String EmployeeNumber() {
		return driver.findElement(ActiveEmployees).getText();
	}
	
	public void SupportClick() {
		driver.findElement(SupportLink).click();
	}
	
	public String TitleSupport() {
		return driver.findElement(SupportTitle).getText();
	}
	
	public String EmailSupport() {
		return driver.findElement(SupportEmail).getText();
	}
	
	public void LogoutClick() {
		driver.findElement(LogoutLink).click();
	}
	
	public void SearchField() {
		driver.findElement(Search).sendKeys("a");
	}
	
	public void BadSearchField() {
		driver.findElement(Search).sendKeys("g");
	}
	
	public String SearchResult() {
		return driver.findElement(SearchText).getText();
	}
	
	public WebElement SearchResultNotFound() {
		 return driver.findElement(SearchNotFound);
	}
	
}
