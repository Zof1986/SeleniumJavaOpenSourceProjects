package PageObjectModel.PageObjectModel;

import static org.testng.Assert.ARRAY_MISMATCH_TEMPLATE;
import static org.testng.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;
import jdk.internal.net.http.common.Log;

public class BuzzTest {

	WebDriver driver;
	
	@BeforeTest
	public void beforetest() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	  @Test
	   public void BuzzLikedPosts() {  // RTM 14.1
			
			driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			driver.manage().window().maximize();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
						
			Login log = new Login(driver);
			
			Buzz buzz = new Buzz(driver);
			
			log.LoginGoodCredentials();
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
	   
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/buzz/viewBuzz");
				
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
				
		buzz.LikedButtonClicked();			
				
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
					
		System.out.println(buzz.NumberLikedFirstPost() +" "+buzz.NumberLikedSecondPost());
		
		Assert.assertTrue(buzz.NumberLikedFirstPost() > buzz.NumberLikedSecondPost());
		
	   }
	   
	   @Test	   
	   
	   public void BuzzComments() {  // RTM 14.2  
			
			driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			driver.manage().window().maximize();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
			Login log = new Login(driver);
			
			Buzz buzz = new Buzz(driver);
									
			log.LoginGoodCredentials();
				
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
	   
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/buzz/viewBuzz");
		
		//driver.findElement(By.xpath("//*[text()='Required']"));
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
	//	driver.findElement(By.xpath("(//button)[8]")).click();
		buzz.CommentsClicked();
	
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
				
		System.out.println(buzz.NumberCommentsFirst() +" "+buzz.NumberCommentSecond());
		
		Assert.assertTrue(buzz.NumberCommentsFirst() > buzz.NumberCommentSecond());
				
	  }
		
	   
	   @Test
	   public void BuzzRecentposts() {  // RTM 14.3
			
			driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			driver.manage().window().maximize();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
			Login log = new Login(driver);
			
			Buzz buzz = new Buzz(driver);
									
			log.LoginGoodCredentials();
				
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
	   
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/buzz/viewBuzz");
		
		//driver.findElement(By.xpath("//*[text()='Required']"));
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}

		buzz.RecentpostCliked();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
				
		System.out.println(buzz.RecentPostFirstClicked() +" "+buzz.RecentPostSecondClicked());
		
		Assert.assertTrue(buzz.RecentPostFirstClicked() > buzz.RecentPostSecondClicked());
				
	  }  

	   @Test	   
	   public void BuzzPicturePost() {  // RTM 14.4
			
			driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			driver.manage().window().maximize();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			Login log = new Login(driver);
			
			Buzz buzz = new Buzz(driver);
									
			log.LoginGoodCredentials();
										
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
	   
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/buzz/viewBuzz");
		
		//driver.findElement(By.xpath("//*[text()='Required']"));
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
				
		Assert.assertTrue(buzz.PicturePostNew().contains("/web/index.php/buzz/photo/"));
		
	   }
	   
	   @Test
	   public void BuzzCreatePost() {  // RTM 14.4
			
			driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			driver.manage().window().maximize();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			Login log = new Login(driver);
			
			Buzz buzz = new Buzz(driver);
									
			log.LoginGoodCredentials();
										
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
	   
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/buzz/viewBuzz");
		
		//driver.findElement(By.xpath("//*[text()='Required']"));
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		
		System.out.println(buzz.DateToday());
		
		buzz.EnterPostTextClick();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		
		System.out.println(buzz.PostText());
				
		Assert.assertEquals(buzz.DateToday(),buzz.PostText());
	  }  
	   
	   @Test
	   public void BuzzYearsOfService() {  // RTM 14.......
			
			driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			driver.manage().window().maximize();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			Login log = new Login(driver);
			
			Buzz buzz = new Buzz(driver);
									
			log.LoginGoodCredentials();
										
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
	   
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/buzz/viewBuzz");
		
		//driver.findElement(By.xpath("//*[text()='Required']"));
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		System.out.println(buzz.BuzzYearExperience());
		
	   }
	   
		
}