package PageObjectModel.PageObjectModel;

import static org.testng.Assert.ARRAY_MISMATCH_TEMPLATE;
import static org.testng.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;
import jdk.internal.net.http.common.Log;

public class RecruitmentTest {

	WebDriver driver;
	
	@BeforeTest
	public void beforetest() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	@Test
	public void AscOrder() {  //RTM 9........
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Recruitment recruit = new Recruitment(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewCandidates");
				
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
			
		 //List<WebElement> al = driver.findElements(By.xpath("//div[@class='oxd-table-card']")); 
	/*	 int Number = driver.findElements(By.xpath("//div[@class='oxd-table-card']")).size(); //pravi metodu
		 System.out.println("broj "+Number);*/
		 
		System.out.println( "broj "+recruit.TotalRowSize());
				
		 List<String> big  = new ArrayList<String>();
		 
		 for(int i = 1; i <=recruit.TotalRowSize();i++) {
			 String beta = driver.findElement(By.xpath("(//div[@class='oxd-table-card'])["+i+"]/div/div[3]")).getText();
			 big.add(beta);
		//	 recruit.FirstList().add(beta);
			 //System.out.println(big.get(i));
		 }
		 
		 try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
		
		 for (String element : big) {
	            System.out.println(element);
	        } 
		 
		 System.out.println("a sad sortirana po ASC");
		
		 try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
		 
		 System.out.println("Second List");
		 		 
		 recruit.Sorting();
		 
		 try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
			 
		 recruit.Ascending();
		 
		 try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
		 
		 List<String> Omni  = new ArrayList<String>(); //metoda
		 
		 for(int i = 1; i <=recruit.TotalRowSize();i++) {
			 String gama = driver.findElement(By.xpath("(//div[@class='oxd-table-card'])["+i+"]/div/div[3]")).getText();
			 Omni.add(gama); //pravi ovde metodu
			// System.out.println(Omni.get(i));
			 recruit.SecondList().add(gama);
		 }
		 
		 try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();   
			}
		 
		 for (String element : Omni) {
	            System.out.println(element);
	        }
		 
		 SoftAssert softAssert = new SoftAssert();
		 
		 softAssert.assertEquals(big.size(), Omni.size());
		 softAssert.assertEquals(big,Omni,"Lists are not equal");
		 
		 softAssert.assertAll();
		 
		 }

	@Test
	public void CheckBoxVisibility() {  //RTM 9........
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Recruitment recruit = new Recruitment(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewCandidates");
				
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
	
		recruit.CheckboxClicked();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
		
	String opacitynew = "0";
	
	//	System.out.println("Opacity "+opacity);
	
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
			
		Assert.assertNotNull(recruit.DeleteButton(), "element not present");
				
		Assert.assertNotEquals(recruit.CheckboxOpacity(), opacitynew);
		
		//checkbox clikcnut stavi opacity 
		
	}
	
	@Test
	public void Vacancies() {  //RTM 9........
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		Login log = new Login(driver);
		Recruitment recruit = new Recruitment(driver);
		
		log.LoginGoodCredentials();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewJobVacancy");
				
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();   
		}
		
	
	 SoftAssert softAssert = new SoftAssert();
	 
	 softAssert.assertEquals(recruit.RemainingNumber(), recruit.OptionFieldAss());
	
	 softAssert.assertAll();
	}
}