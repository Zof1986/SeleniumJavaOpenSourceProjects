package PageObjectModel.PageObjectModel;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;

public class TestAutomation {

WebDriver driver;
	
    
    By SecondPaginationPageColor = By.xpath("(//ul/li/a)[2]");
    
	public TestAutomation(WebDriver driver) {
		this.driver=driver;
	}
	
	public String CurrentUrl() {
		String Url = driver.getCurrentUrl();
		return Url;
	}
	
	
	
}
