package PageObjectModel.PageObjectModel;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Claim {

	
WebDriver driver;
	
	public Claim(WebDriver driver) {
		this.driver = driver;
	}
	
	By ItemInList = By.xpath("//ul[@class='oxd-dropdown-menu']/li/a");
	
	By HeaderDropdowns = By.xpath("//span[@class='oxd-topbar-body-nav-tab-item']");
	
	By EmployeeHintPath = By.xpath("(//input[@placeholder='Type for hints...'])[1]");
	
	By ReferneceId = By.xpath("(//input[@placeholder='Type for hints...'])[2]");
	
	By Reset = By.xpath("(//button)[4]");
	
	public int ClaimNumberOfItemsInList() {
		List<WebElement> lst = driver.findElements(ItemInList);
		int TotalItemsInList = lst.size();
		return TotalItemsInList;
	}
	
	public int ClaimNumberOfCharactersInItemInList() {
		String Text = driver.findElement(ItemInList).getText();
		int NumberOfText = Text.length();
		return NumberOfText;
	}
	
	public int ClaimNumberOfHeadearDropdowns() {
		List<WebElement> lst = driver.findElements(HeaderDropdowns);
		int TotalDropdownsInHeader = lst.size();
		return TotalDropdownsInHeader;
	}
	
	public String EmployeeHint() {
		//driver.findElement(EmployeeHintPath).sendKeys("test"); 
		String ValueOld = driver.findElement(EmployeeHintPath).getAttribute("value");
		return ValueOld;
	}
	
	public String ReferenceId() {
	//	driver.findElement(ReferneceId).sendKeys("test"); 
		String ValueOld = driver.findElement(ReferneceId).getAttribute("value");
		return ValueOld;
	}
		
	public void ResetClick() {
		driver.findElement(Reset);
	}
			
	  
	//driver.findElement(By.xpath("(//input[@placeholder='Type for hints...'])[1]")).sendKeys("test"); EmpnameHint
	//driver.findElement(By.xpath("(//input[@placeholder='Type for hints...'])[2]")).sendKeys("test"); ReferenceHint
	
}
