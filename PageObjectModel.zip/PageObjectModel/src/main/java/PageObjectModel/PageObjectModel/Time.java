package PageObjectModel.PageObjectModel;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Time {

	
WebDriver driver;
	
	public Time(WebDriver driver) {
		this.driver = driver;
	}
	
	By SubmitButton = By.xpath("//button[@type='submit']");
	
	By Error = By.xpath("(//div/span)[2]");
	
	By TimeSheetRecordsRow = By.xpath("//div[@class='oxd-table-card']");
	
	By RemainingPath = By.xpath("//span[@class='oxd-text oxd-text--span']");
	
	By TableViewButton = By.xpath("//button[@class='oxd-button oxd-button--medium oxd-button--text oxd-table-cell-action-space']");
	
	By TotalDuration = By.xpath("//span[@class='oxd-text oxd-text--span orangehrm-header-total']");
	
	By AttendencieRow = By.xpath("//div[@class='orangehrm-attendance-field-row']");

	By SortIcon = By.xpath("//div[@class='oxd-table-header-sort']");
	
	By DescOrder = By.xpath("//i[@class='oxd-icon bi-sort-alpha-up']");
	
	By RowText = By.xpath("(//div[@class='oxd-table-card'])[1]");
	
	By ItemInList = By.xpath("//ul[@class='oxd-dropdown-menu']/li/a");
		
	By HeaderDropdowns = By.xpath("//span[@class='oxd-topbar-body-nav-tab-item']");
	
	
	public void SubmitClick() {
		driver.findElement(SubmitButton).click();
	}
	
	public String Errortext() {
		return driver.findElement(Error).getText();
	}
	
	public int OptionFieldAss() {
		List<WebElement> lst = driver.findElements(TimeSheetRecordsRow);
		int OptNum = lst.size();
		return OptNum;
	}
	
	public int AttendencieWebElementSize() {
		List<WebElement> lst = driver.findElements(AttendencieRow);
		int OptNum = lst.size();
		return OptNum;
	}
	
	
	public int RemainingNumber() {
		String testni = driver.findElement(RemainingPath).getText();
		String ready = testni.substring(testni.indexOf('(') + 1, testni.indexOf(')'));	
		int readynum = Integer.parseInt(ready);
		return readynum;
	}
	
	public String LastNumber() {
		String testni = driver.findElement(TotalDuration).getText();
		String last = testni.substring(testni.lastIndexOf(' ') + 1);
	//	double readynum = Double.parseDouble(last);
		return last;
	}
	
	public int ViewButtonNumber() {
		List<WebElement> lst = driver.findElements(TableViewButton);
		int ViewNum = lst.size();
		return ViewNum;
	}	
	
	public void SortButtonClick() {
		driver.findElement(SortIcon).click();
	}
	
	public void DescendingOrder() {
		driver.findElement(DescOrder).click();
	}
	
	public String RowSorting() {
		String TextRow = driver.findElement(RowText).getText();
		return TextRow;
	}
	
	public int TimeNumberOfItemsInList() {
		List<WebElement> lst = driver.findElements(ItemInList);
		int TotalItemsInList = lst.size();
		return TotalItemsInList;
	}
	
	public int TimeNumberOfCharactersInItemInList() {
		String Text = driver.findElement(ItemInList).getText();
		int NumberOfText = Text.length();
		return NumberOfText;
	}
	
	public int TimeNumberOfHeadearDropdowns() {
		List<WebElement> lst = driver.findElements(HeaderDropdowns);
		int TotalDropdownsInHeader = lst.size();
		return TotalDropdownsInHeader;
	}
	
	public String EmployeeRow() {
		String EmployeeRow = driver.findElement(By.xpath("//div[@class='oxd-table-card']")).getText();
		return EmployeeRow;
	}
		
	
	//https://opensource-demo.orangehrmlive.com/web/index.php/time/viewProjects
	// isto kao za customers Name Description
	
}
