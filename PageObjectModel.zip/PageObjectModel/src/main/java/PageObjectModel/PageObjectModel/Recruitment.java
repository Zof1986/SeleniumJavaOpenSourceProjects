package PageObjectModel.PageObjectModel;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Recruitment {

	
WebDriver driver;
	
	public Recruitment(WebDriver driver) {
		this.driver = driver;
	}
	
	By SubmitButton = By.xpath("//button[@type='submit']");
	
	By Error = By.xpath("(//div/span)[2]");
	
	By TimeSheetRecordsRow = By.xpath("//div[@class='oxd-table-card']");
	
	By RemainingPath = By.xpath("//span[@class='oxd-text oxd-text--span']");
	
	By TableViewButton = By.xpath("//button[@class='oxd-button oxd-button--medium oxd-button--text oxd-table-cell-action-space']");
	
	By TotalDuration = By.xpath("//span[@class='oxd-text oxd-text--span orangehrm-header-total']");
	
	By AttendencieRow = By.xpath("//div[@class='orangehrm-attendance-field-row']");

	By SortIcon = By.xpath("//div[@class='oxd-table-header-sort']");
	
	By DescOrder = By.xpath("//i[@class='oxd-icon bi-sort-alpha-up']");
	
	By RowText = By.xpath("(//div[@class='oxd-table-card'])[1]");
	
	By Sort = By.xpath("(//div[@class='oxd-table-header-sort'])[2]");
	
	By Ascend = By.xpath("(//span[text()='Ascending'])[2]");
	
	By CheckBox = By.xpath("(//span[@class='oxd-checkbox-input oxd-checkbox-input--active --label-right oxd-checkbox-input'])[2]");
	
	By CheckboxOpacity = By.xpath("(//span[@class='oxd-checkbox-input oxd-checkbox-input--active --label-right oxd-checkbox-input'])[2]");
	
	
	public void SubmitClick() {
		driver.findElement(SubmitButton).click();
	}
	
	public String Errortext() {
		return driver.findElement(Error).getText();
	}
	
	public int OptionFieldAss() {
		List<WebElement> lst = driver.findElements(TimeSheetRecordsRow);
		int OptNum = lst.size();
		return OptNum;
	}
	
	public int AttendencieWebElementSize() {
		List<WebElement> lst = driver.findElements(AttendencieRow);
		int OptNum = lst.size();
		return OptNum;
	}
	
	
	public int RemainingNumber() {
		String testni = driver.findElement(RemainingPath).getText();
		String ready = testni.substring(testni.indexOf('(') + 1, testni.indexOf(')'));	
		int readynum = Integer.parseInt(ready);
		return readynum;
	}
	
	public String LastNumber() {
		String testni = driver.findElement(TotalDuration).getText();
		String last = testni.substring(testni.lastIndexOf(' ') + 1);
	//	double readynum = Double.parseDouble(last);
		return last;
	}
	
		
	public int ViewButtonNumber() {
		List<WebElement> lst = driver.findElements(TableViewButton);
		int ViewNum = lst.size();
		return ViewNum;
	}	
	
	public void SortButtonClick() {
		driver.findElement(SortIcon).click();
	}
	
	public void DescendingOrder() {
		driver.findElement(DescOrder).click();
	}
	
	public String RowSorting() {
		String TextRow = driver.findElement(RowText).getText();
		return TextRow;
	}
	
	public int TotalRowSize() {
	   int Number =	driver.findElements(TimeSheetRecordsRow).size();
	   return Number;
	}
	
	public List<String> FirstList() {
		List<String> big  = new ArrayList<String>();
		return big;
	}
	
	public List<String> SecondList() {
		List<String> Omni  = new ArrayList<String>();
		return Omni;
	}
	
	public void Sorting() {
		driver.findElement(Sort).click();
	}
	
	public void Ascending() {
		driver.findElement(Ascend).click();
	}
	
	public void CheckboxClicked() {
		driver.findElement(CheckBox).click();
	}
	
	public String CheckboxOpacity() {
		String Opacity = driver.findElement(CheckboxOpacity).getCssValue("opacity"); 
		return Opacity;
	}
	
	public WebElement DeleteButton() {
		WebElement DeleteButton = driver.findElement(By.xpath("//button[text()=' Delete Selected ']"));
		return DeleteButton;
	}
	
	
	//https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewCandidates
	// pogledaj Candidates and Vacancies
	// ascending i descneind kada se napravi list onda mora da se vrsi neko sortiranje preko kolekcije istrazi
	
}
