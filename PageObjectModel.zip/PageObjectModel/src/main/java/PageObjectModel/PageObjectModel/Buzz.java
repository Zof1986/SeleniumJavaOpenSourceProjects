package PageObjectModel.PageObjectModel;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Buzz {


WebDriver driver;
	
	public Buzz(WebDriver driver) {
		this.driver = driver;
	}

	By LikedpostButton = By.xpath("(//button)[7]");
	
	By FirstCardLikeposts = By.xpath("(//p[contains(., 'Like')])[1]");
	
	By SecondCardLikeposts = By.xpath("(//p[contains(., 'Like')])[2]");
	
	By MostCommmentedButton = By.xpath("(//button)[8]");
	
	By FirstComment = By.xpath("(//p[contains(., 'Comment')])[1]");
	
	By SecondComment = By.xpath("(//p[contains(., 'Comment')])[2]");
			
	By RecentPost = By.xpath("(//button)[6]");
	
	By RecentPostFirst = By.xpath("(//p[@class='oxd-text oxd-text--p orangehrm-buzz-post-time'])[1]");
	
	By RecentPostSecond = By.xpath("(//p[@class='oxd-text oxd-text--p orangehrm-buzz-post-time'])[2]");
			
	By PicturePost = By.xpath("(//div[@class='orangehrm-buzz-photos'])[1]/div/img");
	
	By PostTextArea = By.xpath("//textarea");
	
	By PostSubmitButton = By.xpath("//button[@type='submit']");
	
	By TopDate = By.xpath("(//p[@class='oxd-text oxd-text--p orangehrm-buzz-post-time'])[1]");
	
	By YearsOfExperience = By.xpath("//div[@class='orangehrm-buzz-anniversary-durations-text']");
	
	public void LikedButtonClicked() {
		driver.findElement(LikedpostButton).click();
	}
	
	public int NumberLikedFirstPost() {
		String first = driver.findElement(FirstCardLikeposts).getText();
		String[] nameParts = first.split(" ");
		String first1 = nameParts[0];
		int firstnumb = Integer.parseInt(first1);
		return firstnumb;
	}
	
	public int NumberLikedSecondPost() {
		String second = driver.findElement(SecondCardLikeposts).getText();
		String[] nameParts = second.split(" ");
		String second1 = nameParts[0];
		int secondnumb = Integer.parseInt(second1);
		return secondnumb;
	}
	
	public void CommentsClicked() {
		driver.findElement(MostCommmentedButton).click();
	}
	
	public int NumberCommentsFirst() {
		String first = driver.findElement(FirstComment).getText();
		String[] nameParts = first.split(" ");
		String first1 = nameParts[0];
		int firstnumb = Integer.parseInt(first1);
		return firstnumb;
	}
	
	public int NumberCommentSecond() {
		String second = driver.findElement(SecondComment).getText();
		String[] imeParts = second.split(" ");
		String second1 = imeParts[0];
		int secondnumb = Integer.parseInt(second1);
		return secondnumb;
	}
	
	public void RecentpostCliked() {
		driver.findElement(RecentPost).click();
	}
	
	public int RecentPostFirstClicked() {
		String first = driver.findElement(RecentPostFirst).getText();
		String[] nameParts = first.split(" ");
		String first1 = nameParts[0];
		int firstnumb = Integer.parseInt(first1);
		return firstnumb;
	}
	
	public int RecentPostSecondClicked() {
		String second = driver.findElement(RecentPostSecond).getText();
		String[] imeParts = second.split(" ");
		String second1 = imeParts[0];
		int secondnumb = Integer.parseInt(second1);
		return secondnumb;
	}
	
	public String PicturePostNew() {
		String PictureName = driver.findElement(PicturePost).getAttribute("src");
		return PictureName;
	}
	
	public String DateToday() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-dd-MM");
		String formattedDate = sdf.format(date);
		return formattedDate;
	}
	
	public void EnterPostTextClick() {
		driver.findElement(PostTextArea).sendKeys("test");
		driver.findElement(PostSubmitButton).click();
	}
	
	public String PostText() {
		String topdate = driver.findElement(TopDate).getText();
		String[] nameParts = topdate.split(" ");
		String first1 = nameParts[0];
		return first1;
	}
	
	public String BuzzYearExperience() {
		String YearsOfService = driver.findElement(YearsOfExperience).getText();
		return YearsOfService;
	}
	
	
}
